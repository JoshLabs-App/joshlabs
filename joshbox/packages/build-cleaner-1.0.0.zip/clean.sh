#!/bin/bash
set -u

ROOT="${JOSHBOX_FIELD_ROOT:-$HOME/Desktop/APP}"
STALE_DAYS="${JOSHBOX_FIELD_STALE_DAYS:-3}"
DRY_RUN=1

IMMEDIATE_PKG_EXT=(apk aab ipa)
IMMEDIATE_NAMES=(__pycache__)
BUILD_NAMES=(dist build .next target DerivedData)
CACHE_NAMES=(node_modules .venv venv Pods)
EXCLUDE_PATHS=(
  "/01榴莲英语/content/build"
)

for arg in "$@"; do
  case "$arg" in
    --real) DRY_RUN=0 ;;
    --stale-days=*) STALE_DAYS="${arg#*=}" ;;
    --root=*) ROOT="${arg#*=}" ;;
  esac
done

if ! [[ "$STALE_DAYS" =~ ^[0-9]+$ ]]; then
  echo "错误：沉寂天数必须是非负整数（当前值：$STALE_DAYS）" >&2
  exit 1
fi

if [ ! -d "$ROOT" ]; then
  echo "错误：目录不存在 -> $ROOT" >&2
  exit 1
fi

log() { echo "[$(date '+%H:%M:%S')] $*"; }

excluded() {
  local d="$1" p
  for p in "${EXCLUDE_PATHS[@]}"; do
    case "$d" in *"$p"*) return 0 ;; esac
  done
  return 1
}

remove_path() {
  local d="$1" size
  if excluded "$d"; then
    log "  [跳过·白名单] $d"
    return
  fi
  size=$(du -sh "$d" 2>/dev/null | cut -f1)
  if [ "$DRY_RUN" = "1" ]; then
    log "  [预览] 会清理 $d ($size)"
  else
    log "  [清理] $d ($size)"
    rm -rf "$d"
  fi
}

MODE_LABEL="预览模式（不删除任何文件）"
[ "$DRY_RUN" = "0" ] && MODE_LABEL="真实清理"
log "==== 开始扫描 $ROOT | 沉寂阈值=${STALE_DAYS}天 | ${MODE_LABEL} ===="

if [ -z "$(find "$ROOT" -mindepth 1 -maxdepth 1 -type d 2>/dev/null | head -1)" ]; then
  log "中止：无法读取 $ROOT 下的子目录（可能为空或未授予磁盘访问权限）。"
  exit 2
fi

BEFORE_KB=0
if [ "$DRY_RUN" = "0" ]; then
  BEFORE_KB=$(du -sk "$ROOT" 2>/dev/null | cut -f1 || echo 0)
fi

for name in "${IMMEDIATE_NAMES[@]}"; do
  find "$ROOT" -maxdepth 8 -type d -name "$name" -not -path "*/node_modules/*" 2>/dev/null \
  | while IFS= read -r d; do remove_path "$d"; done
done

for ext in "${IMMEDIATE_PKG_EXT[@]}"; do
  find "$ROOT" -maxdepth 10 -type f -name "*.$ext" -not -path "*/node_modules/*" 2>/dev/null \
  | while IFS= read -r f; do remove_path "$f"; done
done

find "$ROOT" -mindepth 1 -maxdepth 1 -type d | while IFS= read -r project; do
  if [ -e "$project/.no-clean" ]; then
    log "[跳过·.no-clean] $(basename "$project")"
    continue
  fi

  recent=$(find "$project" \
    \( -name node_modules -o -name .venv -o -name venv -o -name Pods \
       -o -name dist -o -name build -o -name .next -o -name target \
       -o -name DerivedData -o -name .git -o -name __pycache__ \) -prune \
    -o -type f -mtime "-${STALE_DAYS}" -print -quit 2>/dev/null)

  if [ -n "$recent" ]; then
    log "[活跃项目·保留] $(basename "$project")"
    continue
  fi

  log "[沉寂项目] $(basename "$project")"
  for name in "${BUILD_NAMES[@]}" "${CACHE_NAMES[@]}"; do
    find "$project" -maxdepth 4 -type d -name "$name" -not -path "*/node_modules/*" 2>/dev/null \
    | while IFS= read -r d; do remove_path "$d"; done
  done
done

if [ "$DRY_RUN" = "0" ]; then
  AFTER_KB=$(du -sk "$ROOT" 2>/dev/null | cut -f1 || echo 0)
  FREED_KB=$((BEFORE_KB - AFTER_KB))
  if [ "$FREED_KB" -lt 0 ]; then FREED_KB=0; fi
  FREED_MB=$(awk "BEGIN {printf \"%.1f\", $FREED_KB / 1024}")
  log "==== 清理完成，共释放约 ${FREED_MB} MB ===="
else
  log "==== 预览完成（未删除任何文件）===="
fi
