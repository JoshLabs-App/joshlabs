(() => {
  'use strict';

  const icons = {
    broom: '✦', folder: '▰', duplicate: '◫', photo: '▧', disk: '◉', privacy: '⌑', apps: '▦', login: '↗', link: '⌁', settings: '⚙', power: '◌'
  };
  const toolDefs = [
    ['large', '大文件', '找出 50 MB 以上的文件', 'folder'],
    ['duplicates', '重复文件', '按内容识别完全相同的文件', 'duplicate'],
    ['photos', '相似照片', '归拢相似照片，自己决定保留哪张', 'photo'],
    ['disk', '磁盘分析', '查看文件夹占用并打开位置', 'disk'],
    ['privacy', '隐私清理', '检查浏览器缓存和历史记录', 'privacy'],
    ['apps', '应用卸载', '检查应用占用，选择后移入废纸篓', 'apps'],
    ['login', '登录与启动项', '查看开机自动运行的项目', 'login'],
    ['sharing', '电脑互联', '管理共享文件夹并连接另一台电脑', 'link']
  ];
  const state = { screen: '', job: null, pollTimer: null, items: [], selected: new Set(), settings: {}, sharing: null, loginItems: null };
  const $ = (selector, root = document) => root.querySelector(selector);
  const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const fmtBytes = value => {
    const n = Number(value) || 0;
    if (n >= 1073741824) return `${(n / 1073741824).toFixed(1)} GB`;
    if (n >= 1048576) return `${(n / 1048576).toFixed(1)} MB`;
    if (n >= 1024) return `${Math.round(n / 1024)} KB`;
    return `${n} B`;
  };
  const bridge = () => typeof window.macpulseRequest === 'function';
  async function request(endpoint, payload = {}) {
    if (!bridge()) throw new Error('请在桌面应用中使用此功能。');
    const result = await window.macpulseRequest(endpoint, payload);
    if (result?.ok === false) throw new Error(result.error || '操作未完成');
    return result || {};
  }
  function toast(message, bad = false) {
    const stack = $('#toastStack');
    if (!stack) { window.alert(message); return; }
    const el = document.createElement('div'); el.className = `toast ${bad ? 'error' : 'success'}`; el.textContent = message; stack.appendChild(el);
    setTimeout(() => el.remove(), 4200);
  }
  function confirmDialog(title, message, confirmLabel = '继续') {
    return new Promise(resolve => {
      const overlay = document.createElement('div'); overlay.className = 'mp-confirm-backdrop'; overlay.setAttribute('role', 'presentation');
      overlay.innerHTML = `<section class="mp-confirm-dialog" role="alertdialog" aria-modal="true" aria-labelledby="mpConfirmTitle"><h2 id="mpConfirmTitle">${esc(title)}</h2><p>${esc(message).replace(/\n/g, '<br>')}</p><div><button type="button" class="mp-secondary-btn" data-confirm="no">取消</button><button type="button" class="mp-primary-btn" data-confirm="yes">${esc(confirmLabel)}</button></div></section>`;
      document.body.appendChild(overlay);
      const finish = value => { overlay.remove(); resolve(value); };
      overlay.addEventListener('click', e => { if (e.target === overlay) finish(false); const button = e.target.closest('[data-confirm]'); if (button) finish(button.dataset.confirm === 'yes'); });
      overlay.addEventListener('keydown', e => { if (e.key === 'Escape') finish(false); });
      $('.mp-secondary-btn', overlay).focus();
    });
  }
  function icon(name) { return `<span class="mp-tool-icon" aria-hidden="true">${icons[name] || '•'}</span>`; }
  function init() {
    const nav = $('.nav-tabs');
    const shell = $('#appShell');
    if (!nav || !shell) return;
    nav.insertAdjacentHTML('beforeend', `
      <button type="button" class="nav-tab" data-tools-tab="tools" role="tab" aria-selected="false">${icon('broom')}<span>清理与工具</span></button>
      <button type="button" class="nav-tab" data-tools-tab="settings" role="tab" aria-selected="false">${icon('settings')}<span>设置</span></button>`);
    // Keep navigation in its own grid cell so actions cannot cover a tab.
    const topbar = nav.closest('.topbar');
    topbar.insertBefore(nav, $('.topbar-actions', topbar));
    shell.insertAdjacentHTML('beforeend', `
      <main class="mp-tools-page hidden" id="mpToolsPage" aria-labelledby="mpToolsTitle">
        <header class="mp-page-heading"><div><div class="mp-eyebrow">MACPULSE · 本机工具</div><h1 id="mpToolsTitle">清理与工具</h1><p>先检查，再由你决定要执行的操作。</p></div><span class="mp-native-badge">${icon('broom')} 本机工具</span></header>
        <section class="mp-tool-grid" aria-label="清理与工具">
          ${toolDefs.map(([id, title, desc, glyph]) => `<button type="button" class="mp-tool-card" data-tool="${id}"><span class="mp-card-icon">${icon(glyph)}</span><span class="mp-card-copy"><strong>${title}</strong><small>${desc}</small></span><span class="mp-card-arrow" aria-hidden="true">›</span></button>`).join('')}
        </section>
        <section class="mp-inline-panel hidden" id="mpToolDetail" aria-live="polite"></section>
      </main>
      <main class="mp-tools-page hidden" id="mpSettingsPage" aria-labelledby="mpSettingsTitle">
        <header class="mp-page-heading"><div><div class="mp-eyebrow">MACPULSE · 偏好设置</div><h1 id="mpSettingsTitle">设置</h1><p>快捷键、截图保存和电源行为。</p></div><span class="mp-native-badge">${icon('settings')} 系统集成</span></header>
        <section class="mp-settings-layout" id="mpSettingsContent"><div class="mp-empty-state">正在读取设置…</div></section>
      </main>`);
    shell.appendChild($('.cockpit-footer', shell));
    nav.addEventListener('click', e => {
      const toolTab = e.target.closest('[data-tools-tab]');
      const normalTab = e.target.closest('[data-main-tab]');
      if (toolTab) { e.preventDefault(); e.stopImmediatePropagation(); showScreen(toolTab.dataset.toolsTab); }
      else if (normalTab) { hideScreens(); }
    }, true);
    $('#mpToolsPage').addEventListener('click', onToolsClick);
    $('#mpSettingsPage').addEventListener('click', onSettingsClick);
    $('#mpToolsPage').addEventListener('change', onToolsChange);
    $('#mpSettingsPage').addEventListener('change', onSettingsChange);
    document.addEventListener('visibilitychange', () => { if (!document.hidden && state.screen === 'settings') loadSettings(); });
  }
  function hideScreens() {
    state.screen = '';
    document.body.classList.remove('mp-utility-view');
    $('#mpToolsPage')?.classList.add('hidden'); $('#mpSettingsPage')?.classList.add('hidden');
    document.querySelectorAll('[data-tools-tab]').forEach(b => { b.classList.remove('active'); b.setAttribute('aria-selected', 'false'); });
  }
  function showScreen(screen) {
    state.screen = screen;
    document.body.classList.add('mp-utility-view');
    $('#tabHardware')?.classList.add('hidden'); $('#tabNetwork')?.classList.add('hidden');
    $('#mpToolsPage').classList.toggle('hidden', screen !== 'tools'); $('#mpSettingsPage').classList.toggle('hidden', screen !== 'settings');
    document.querySelectorAll('[data-main-tab]').forEach(b => { b.classList.remove('active'); b.setAttribute('aria-selected', 'false'); });
    document.querySelectorAll('[data-tools-tab]').forEach(b => { const on = b.dataset.toolsTab === screen; b.classList.toggle('active', on); b.setAttribute('aria-selected', String(on)); });
    if (screen === 'settings') loadSettings();
  }
  function onToolsClick(e) {
    const card = e.target.closest('[data-tool]'); if (card) { openTool(card.dataset.tool); return; }
    const action = e.target.closest('[data-action]')?.dataset.action; if (!action) return;
    const handlers = { chooseRoot, startScan, cancelScan, trashSelected, revealItem, selectAllSafe, loadLoginItems, openLoginSettings, openUtility, loadSharing, chooseShareFolder, addShare, removeShare, connectShare, connectNamedShare, testShare, openSharingSettings, copyShareAddress, returnTools };
    handlers[action]?.(e.target.closest('[data-action]'));
  }
  function onToolsChange(e) {
    if (e.target.matches('[data-item-id]')) {
      const item = state.items.find(x => x.id === e.target.dataset.itemId);
      if (!item) return;
      if (e.target.checked) state.selected.add(item.id); else state.selected.delete(item.id);
      if (item.group && ['duplicates', 'photos'].includes(state.job?.kind)) {
        const group = state.items.filter(x => x.group === item.group);
        if (!group.some(x => !x.canTrash || !state.selected.has(x.id))) {
          state.selected.delete(item.id);
          toast('每组至少保留一份。', true);
        }
      }
      renderItems();
    }
  }
  async function openTool(id) {
    const detail = $('#mpToolDetail'); detail.classList.remove('hidden');
    if (id === 'sharing') return loadSharing();
    if (id === 'login') return loadLoginItems();
    if (id === 'apps') return renderUtilities();
    detail.innerHTML = `<div class="mp-panel-heading"><div><div class="mp-eyebrow">${icon(toolDefs.find(x => x[0] === id)?.[3])} 检查工具</div><h2>${esc(toolDefs.find(x => x[0] === id)?.[1] || '检查')}</h2></div><button class="mp-quiet-btn" data-action="returnTools">返回工具</button></div>
      <p class="mp-panel-note">${id === 'privacy' ? '只列出可清理的临时文件；不会读取或清除浏览器 Cookie、书签或密码。开始前请关闭浏览器。' : id === 'photos' ? '相似照片按组展示。可以选择组内多张，但每组至少保留一张。' : id === 'duplicates' ? '重复文件依据内容识别。可以选择多份，但每组至少保留一份。' : id === 'large' ? '默认筛选 50 MB 以上的文件。扫描不会选择任何个人文件。' : id === 'disk' ? '默认分析“下载”文件夹；你可以选择其他文件夹。此工具只显示占用情况，不会删除文件。' : '检查结果仅用于查看文件夹占用；可打开位置进行检查。'}</p>
      <div class="mp-control-row"><button class="mp-secondary-btn" data-action="chooseRoot">${icon('folder')} 选择扫描位置</button><span class="mp-selected-root" id="mpRootLabel">未选择（默认“下载”文件夹）</span>${id === 'large' ? '<label class="mp-inline-field">最小大小 <select id="mpMinSize"><option value="52428800">50 MB</option><option value="104857600">100 MB</option><option value="536870912">500 MB</option></select></label>' : ''}<button class="mp-primary-btn" data-action="startScan">开始检查</button></div>
      <div id="mpScanProgress"></div><div id="mpResults"></div>`;
    state.activeKind = id; state.root = '';
  }
  async function chooseRoot() {
    try { const result = await request('/api/tools/pick-folder'); if (result.path) { state.root = result.path; $('#mpRootLabel').textContent = result.path; } }
    catch (e) { toast(e.message, true); }
  }
  async function startScan() {
    const kind = state.activeKind; if (!kind) return;
    state.selected.clear(); state.items = [];
    $('#mpResults').innerHTML = ''; $('#mpScanProgress').innerHTML = '<div class="mp-progress" role="status"><div><span>正在检查…</span><strong id="mpProgressLabel">准备中</strong></div><div class="mp-progress-track"><i></i></div><button class="mp-quiet-btn" data-action="cancelScan">取消</button></div>';
    try {
      const minBytes = Number($('#mpMinSize')?.value || 0);
      const result = await request('/api/tools/start', { kind, root: state.root || undefined, minBytes: minBytes || undefined });
      state.job = { id: result.jobId, kind }; pollJob();
    } catch (e) { $('#mpScanProgress').innerHTML = `<div class="mp-inline-error">${esc(e.message)}</div>`; }
  }
  async function pollJob() {
    clearTimeout(state.pollTimer); if (!state.job) return;
    try {
      const result = await request('/api/tools/status', { jobId: state.job.id });
      const progress = result.progress || {};
      const label = $('#mpProgressLabel'); if (label) label.textContent = `${progress.files || 0} 个项目 · ${fmtBytes(progress.bytes || 0)}${progress.current ? ` · ${progress.current}` : ''}`;
      if (result.state === 'running') { state.pollTimer = setTimeout(pollJob, 700); return; }
      state.items = Array.isArray(result.items) ? result.items : []; state.summary = result.summary || {}; state.selected.clear();
      if (result.state === 'error') throw new Error(result.error || '检查失败');
      if (result.state === 'cancelled') { $('#mpScanProgress').innerHTML = '<div class="mp-result-summary">检查已取消。</div>'; return; }
      renderSummary(); renderItems();
    } catch (e) { $('#mpScanProgress').innerHTML = `<div class="mp-inline-error">${esc(e.message)}</div>`; }
  }
  async function cancelScan() { if (!state.job) return; try { await request('/api/tools/cancel', { jobId: state.job.id }); clearTimeout(state.pollTimer); state.job = null; $('#mpScanProgress').innerHTML = '<div class="mp-result-summary">已取消检查。</div>'; } catch (e) { toast(e.message, true); } }
  function renderSummary() {
    const s = state.summary || {};
    $('#mpScanProgress').innerHTML = `<div class="mp-result-summary"><span><strong>${Number(s.files ?? state.items.length)}</strong> 个项目</span><span><strong>${fmtBytes(s.bytes)}</strong> 可查看</span>${s.skipped ? `<span>${Number(s.skipped)} 项已跳过</span>` : ''}${s.truncated ? '<span>结果较多，已显示部分项目</span>' : ''}</div>`;
  }
  function renderItems() {
    const box = $('#mpResults'); if (!box) return;
    if (!state.items.length) { box.innerHTML = '<div class="mp-empty-state">没有找到匹配项目。</div>'; return; }
    const canTrash = state.job?.kind !== 'disk';
    const hasSelectable = state.items.some(x => x.canTrash && canTrash);
    box.innerHTML = `<div class="mp-results-head"><h3>检查结果 <span>${state.items.length}</span></h3><div>${hasSelectable ? `<button class="mp-quiet-btn" data-action="selectAllSafe">选择可移入废纸篓项目</button><button class="mp-danger-btn" data-action="trashSelected" ${state.selected.size ? '' : 'disabled'}>移入废纸篓 (${state.selected.size})</button>` : ''}</div></div>
      <div class="mp-item-list">${state.items.map(item => `<article class="mp-item-row"><label class="mp-item-check">${item.canTrash && canTrash ? `<input type="checkbox" data-item-id="${esc(item.id)}" data-testid="item-${esc(item.id)}" ${state.selected.has(item.id) ? 'checked' : ''} aria-label="选择 ${esc(item.name)}">` : '<span class="mp-readonly-dot" aria-label="保留项目"></span>'}</label><div class="mp-item-main"><strong title="${esc(item.path)}">${esc(item.name || item.path)}</strong><small>${esc(item.detail || item.path || '')}</small>${item.group ? `<span class="mp-item-group">${esc(item.group)}${item.canTrash ? '' : ' · 保留一份'}</span>` : ''}</div><span class="mp-item-size">${fmtBytes(item.bytes)}</span><button class="mp-quiet-btn" data-action="revealItem" data-item-id="${esc(item.id)}" data-testid="reveal-${esc(item.id)}">显示位置</button></article>`).join('')}</div>`;
  }
  function selectAllSafe() {
    for (const item of state.items) {
      if (!item.canTrash) continue;
      if (item.group && ['duplicates', 'photos'].includes(state.job?.kind)) {
        const group = state.items.filter(other => other.group === item.group);
        if (!group.some(other => !other.canTrash)) {
          const first = group.find(other => other.canTrash);
          if (first?.id === item.id) continue;
        }
      }
      state.selected.add(item.id);
    }
    renderItems();
  }
  async function revealItem(button) { try { await request('/api/tools/reveal', { id: button.dataset.itemId }); } catch (e) { toast(e.message, true); } }
  async function trashSelected() {
    const items = state.items.filter(item => state.selected.has(item.id));
    if (!items.length || items.some(x => !x.canTrash)) return;
    const bytes = items.reduce((sum, x) => sum + (Number(x.bytes) || 0), 0);
    if (!window.confirm(`确定将 ${items.length} 项（约 ${fmtBytes(bytes)}）移入废纸篓吗？文件仍可从废纸篓恢复。`)) return;
    try {
      const result = await request('/api/tools/trash', { ids: items.map(x => x.id) });
      const removed = new Set((result.successes || result.moved || []).map(x => typeof x === 'string' ? x : x.id));
      if (!removed.size && !result.errors?.length) { state.items = []; }
      else state.items = state.items.filter(x => !removed.has(x.id));
      state.selected.clear(); renderItems();
      toast(result.errors?.length ? `${removed.size} 项已移入废纸篓，${result.errors.length} 项未能处理。` : `${removed.size || items.length} 项已移入废纸篓。`, Boolean(result.errors?.length));
    } catch (e) { toast(e.message, true); }
  }
  function renderUtilities() {
    const detail = $('#mpToolDetail'); detail.classList.remove('hidden');
    const utilityDefs = [['activity-monitor', '活动监视器', '查看 CPU、内存和进程'], ['system-settings', '系统设置', '打开 macOS 设置'], ['login-items', '登录项设置', '管理登录时启动的应用'], ['full-disk-access', '完整磁盘访问', '检查文件访问权限']];
    detail.innerHTML = `<div class="mp-panel-heading"><div><div class="mp-eyebrow">${icon('apps')} 应用卸载与管理</div><h2>已安装应用</h2></div><button class="mp-quiet-btn" data-action="returnTools">返回工具</button></div><p class="mp-panel-note">查看应用及其缓存、偏好设置、日志的占用，可分别勾选。运行中的应用和系统组件会保留。确认后所选项目移入废纸篓。</p><div class="mp-control-row"><span class="mp-selected-root">扫描“应用程序”文件夹中的应用</span><button class="mp-primary-btn" data-action="startScan">检查应用</button></div><div id="mpScanProgress"></div><div id="mpResults"></div><div class="mp-section-divider"></div><h3 class="mp-subheading">Mac 实用工具</h3><div class="mp-utility-grid">${utilityDefs.map(([id, name, desc]) => `<article class="mp-utility-card"><div>${icon('apps')}<strong>${name}</strong><small>${desc}</small></div><button class="mp-secondary-btn" data-action="openUtility" data-id="${id}">打开</button></article>`).join('')}</div>`;
    state.activeKind = 'apps'; state.root = '';
  }
  async function openUtility(button) { try { await request('/api/utility/open', { id: button.dataset.id }); } catch (e) { toast(e.message, true); } }
  function returnTools() { $('#mpToolDetail').classList.add('hidden'); }
  async function loadLoginItems() {
    const detail = $('#mpToolDetail'); detail.classList.remove('hidden'); detail.innerHTML = '<div class="mp-empty-state">正在读取登录项…</div>';
    try {
      const data = await request('/api/login/list'); state.loginItems = data.items || [];
      detail.innerHTML = `<div class="mp-panel-heading"><div><div class="mp-eyebrow">${icon('login')} macOS 登录项</div><h2>登录与启动项</h2></div><button class="mp-quiet-btn" data-action="returnTools">返回工具</button></div><p class="mp-panel-note">登录项设置由 macOS 管理。打开系统页面后，你可以自行查看和调整。</p><div class="mp-control-row"><span class="mp-status-line">${esc(data.message || `发现 ${state.loginItems.length} 个项目`)}</span><button class="mp-primary-btn" data-action="openLoginSettings">打开 macOS 登录项设置</button></div><div class="mp-item-list">${state.loginItems.map(item => `<article class="mp-item-row mp-readonly-row"><span class="mp-readonly-dot"></span><div class="mp-item-main"><strong>${esc(item.name)}</strong><small>${esc(item.detail || item.path || '')}</small></div><span class="mp-status-tag">${item.enabled === true ? '启用中' : item.enabled === false ? '已停用' : '状态未知'}</span></article>`).join('') || '<div class="mp-empty-state">未取得登录项列表。你仍可在 macOS 设置中管理。</div>'}</div>`;
    } catch (e) { detail.innerHTML = `<div class="mp-panel-heading"><h2>登录与启动项</h2><button class="mp-quiet-btn" data-action="returnTools">返回工具</button></div><div class="mp-inline-error">${esc(e.message)}</div><button class="mp-primary-btn" data-action="openLoginSettings">打开 macOS 登录项设置</button>`; }
  }
  async function openLoginSettings() { try { await request('/api/login/settings'); } catch (e) { toast(e.message, true); } }
  async function loadSharing() {
    const detail = $('#mpToolDetail'); detail.classList.remove('hidden'); detail.innerHTML = '<div class="mp-empty-state">正在读取电脑互联状态…</div>';
    try {
      const data = await request('/api/sharing/status'); state.sharing = data;
      renderSharing();
    } catch (e) { detail.innerHTML = `<div class="mp-panel-heading"><div><div class="mp-eyebrow">${icon('link')} 电脑互联</div><h2>共享文件夹</h2></div><button class="mp-quiet-btn" data-action="returnTools">返回工具</button></div><div class="mp-inline-error">${esc(e.message)}</div>`; }
  }
  function renderSharing() {
    const data = state.sharing || {}; const addresses = data.addresses || [];
    const firstAddress = String(addresses[0] || '').replace(/^smb:\/\//, '');
    const winHost = firstAddress || data.hostName || data.computerName || '本机名称';
    const smbHost = firstAddress || data.hostName || data.computerName || '本机名称';
    const shareRows = (data.shares || []).map(s => {
      const smb = `smb://${smbHost}/${encodeURIComponent(s.name)}`;
      const unc = `\\\\${winHost}\\${s.name}`;
      return `<article class="mp-item-row mp-share-row"><div class="mp-item-main"><strong>${esc(s.name)}</strong><small>${esc(s.path)}</small><small class="mp-share-paths"><span>Mac</span> <code>${esc(smb)}</code> <span>Windows</span> <code>${esc(unc)}</code></small><small class="mp-share-security">${s.guestEnabled ? '访客访问已开启' : '需要账户登录'} · ${s.readOnly === false ? '可写入' : '远端只读'}${s.encrypted === true ? ' · SMB 加密' : ' · 未要求 SMB 加密'}</small></div><button class="mp-secondary-btn" data-action="connectNamedShare" data-address="${esc(smb)}">Finder 打开</button><button class="mp-danger-quiet" data-action="removeShare" data-name="${esc(s.name)}">移除共享</button></article>`;
    }).join('');
    $('#mpToolDetail').innerHTML = `<div class="mp-panel-heading"><div><div class="mp-eyebrow">${icon('link')} 电脑互联</div><h2>共享文件夹</h2></div><button class="mp-quiet-btn" data-action="returnTools">返回工具</button></div>
      <div class="mp-share-overview"><div><span>本机</span><strong>${esc(data.computerName || data.hostName || 'Mac')}</strong><small>${data.smbRunning ? '检测到 SMB 服务监听' : '未检测到 SMB 服务监听'}</small></div><div class="mp-share-addresses">${addresses.length ? addresses.map(address => `<button class="mp-address-pill" data-action="copyShareAddress" data-address="${esc(address)}" title="复制地址">${esc(address)}　复制</button>`).join('') : '<small>暂未取得本机地址</small>'}</div><button class="mp-secondary-btn" data-action="openSharingSettings">macOS 共享设置</button></div>
      <div class="mp-instructions"><div><strong>Mac ↔ Mac</strong><span>在另一台 Mac 的 Finder 按 ⌘K，输入某个共享行列出的 <code>smb://电脑地址/共享名</code>；输入 Mac 账户与密码登录。本机也可用“Finder 打开”。</span></div><div><strong>Mac ↔ Windows</strong><span>在 Windows 文件资源管理器地址栏输入共享行列出的 UNC 路径（以两个反斜杠开头）。用本机账户登录；访客访问默认关闭。</span></div></div>
      <div class="mp-share-tools"><label class="mp-inline-field">连接其他共享<input id="mpConnectAddress" type="text" placeholder="smb://电脑地址/共享名" autocomplete="off"></label><button class="mp-primary-btn" data-action="connectShare">在 Finder 中打开</button><label class="mp-inline-field">测试另一台电脑<input id="mpShareHost" type="text" placeholder="主机名或 IP 地址" autocomplete="off"></label><button class="mp-secondary-btn" data-action="testShare">测试连接</button><span id="mpShareTestResult" aria-live="polite"></span></div>
      <div class="mp-results-head"><h3>当前共享 <span>${(data.shares || []).length}</span></h3><button class="mp-primary-btn" data-action="chooseShareFolder">选择文件夹并共享</button></div>
      <p class="mp-panel-note">只有 SMB 服务已开启并且另一台电脑可连接时，远端访问才可用。Finder 打开和 445 端口连通仅表示已发起连接或网络可达，不代表共享磁盘已挂载。只共享你亲自选定的文件夹；访客访问默认关闭。</p><div class="mp-item-list">${shareRows || '<div class="mp-empty-state">还没有共享文件夹。</div>'}</div>`;
  }
  async function chooseShareFolder() {
    try { const result = await request('/api/sharing/pick-folder'); if (!result.path) return; const name = result.path.split('/').filter(Boolean).pop() || '共享文件夹'; const confirmed = await confirmDialog('添加共享文件夹', `将此文件夹提供给本地网络中的电脑访问？\n\n${result.path}\n\n远端只读，使用账户认证，不开放访客访问。`, '添加共享'); if (!confirmed) return; await request('/api/sharing/add', { path: result.path, name }); await loadSharing(); toast('共享文件夹已添加。'); }
    catch (e) { toast(e.message, true); }
  }
  async function addShare() { return chooseShareFolder(); }
  async function removeShare(button) { if (!await confirmDialog('移除共享', `确定停止共享“${button.dataset.name}”吗？`, '移除共享')) return; try { await request('/api/sharing/remove', { name: button.dataset.name }); await loadSharing(); toast('共享已移除。'); } catch (e) { toast(e.message, true); } }
  async function connectShare() { const address = $('#mpConnectAddress')?.value?.trim(); if (!address) return toast('请输入 smb:// 地址。', true); try { await request('/api/sharing/connect', { address }); } catch (e) { toast(e.message, true); } }
  async function connectNamedShare(button) { try { await request('/api/sharing/connect', { address: button.dataset.address }); toast('已在 Finder 中打开连接请求；请完成账户登录。'); } catch (e) { toast(e.message, true); } }
  async function testShare() { const host = $('#mpShareHost')?.value?.trim(); if (!host) return toast('请先输入主机名或 IP 地址。', true); const out = $('#mpShareTestResult'); out.textContent = '正在测试…'; try { const r = await request('/api/sharing/test', { host }); out.textContent = r.reachable ? `已连通${r.port ? ` · 端口 ${r.port}` : ''}` : (r.message || '未连通'); out.className = r.reachable ? 'mp-test-ok' : 'mp-test-no'; } catch (e) { out.textContent = e.message; out.className = 'mp-test-no'; } }
  async function openSharingSettings() { try { await request('/api/sharing/open-settings'); } catch (e) { toast(e.message, true); } }
  async function copyShareAddress(button) { try { await request('/api/sharing/copy-address', { address: button.dataset.address }); toast('本机地址已复制。'); } catch (e) { toast(e.message, true); } }
  async function loadSettings() {
    const content = $('#mpSettingsContent'); if (!content) return;
    try {
      const data = await request('/api/settings'); state.settings = data.settings || {};
      const s = state.settings, p = data.power || {}, shortcut = data.shortcut || {}, screenshot = data.screenshot || {}, login = data.loginItems || {};
      const launchAtLogin = typeof s.launchAtLogin === 'boolean' ? s.launchAtLogin : Boolean(login.enabled);
      const loginStatus = ({ enabled: '当前已启用', notRegistered: '启用后自动启动 MacPulse。', notFound: '启用后自动启动 MacPulse。', requiresApproval: '请在 macOS 登录项设置中允许启动。' })[login.status] || '启用后自动启动 MacPulse。';
      const durationChoices = [30, 60, 120, 240, 720];
      const duration = durationChoices.includes(Number(s.durationMinutes)) ? Number(s.durationMinutes) : 60;
      const lidExternallyDisabled = Boolean(p.lidSleepDisabled) && !Boolean(p.lidSleepOwnedByMacPulse);
      content.innerHTML = `<section class="mp-settings-card"><div class="mp-section-title"><div><span class="mp-setting-icon">${icon('power')}</span><h2>电源与唤醒</h2></div></div>
        <label class="mp-setting-row"><span><strong>保持本机唤醒</strong><small>让任务在电脑空闲时继续运行。</small></span><input type="checkbox" data-setting="keepAwake" data-testid="setting-keepAwake" ${s.keepAwake ? 'checked' : ''}><i class="mp-switch"></i></label>
        <label class="mp-setting-row"><span><strong>保持显示器点亮</strong><small>适合长时间查看仪表盘。</small></span><input type="checkbox" data-setting="displayAwake" data-testid="setting-displayAwake" ${s.displayAwake ? 'checked' : ''}><i class="mp-switch"></i></label>
        <label class="mp-setting-row"><span><strong>保持唤醒时长</strong><small>本机唤醒保持的持续时间。</small></span><select class="mp-duration-select" data-setting="durationMinutes" data-testid="setting-duration"><option value="30" ${duration === 30 ? 'selected' : ''}>30 分钟</option><option value="60" ${duration === 60 ? 'selected' : ''}>1 小时</option><option value="120" ${duration === 120 ? 'selected' : ''}>2 小时</option><option value="240" ${duration === 240 ? 'selected' : ''}>4 小时</option><option value="720" ${duration === 720 ? 'selected' : ''}>12 小时</option></select></label>
        <label class="mp-setting-row"><span><strong>合盖后继续运行</strong><small class="mp-warning-copy">合盖运行会增加发热和耗电。请将 Mac 接上电源并保持通风。</small></span><input type="checkbox" data-setting="lidClosedMode" data-testid="setting-lidClosedMode" ${s.lidClosedMode ? 'checked' : ''}><i class="mp-switch"></i></label>
        ${lidExternallyDisabled ? '<p class="mp-panel-note">macOS 此前已关闭系统睡眠；这项设置并非由 MacPulse 启用。关闭上方开关可重新允许系统睡眠。</p>' : ''}
        ${p.restorationPending ? `<div class="mp-restore-row"><span>${p.restorationPending ? '原有睡眠设置等待恢复。' : '合盖运行由 MacPulse 保持；恢复时会还原启用前的设置。'}</span><button class="mp-secondary-btn" data-action="restoreLidSleep" data-testid="restore-lid">恢复原有设置</button></div>` : ''}
        <div class="mp-setting-status">${p.idleAssertionActive ? '本机唤醒保持中' : '空闲唤醒保持未启用'}${p.displayAssertionActive ? ' · 显示器保持点亮' : ''}${p.lidSleepDisabled ? ' · 系统当前合盖不睡眠' : ''}${p.originalSleepDisabled ? ' · 原有系统设置也是合盖不睡眠' : ''}${p.restorationPending ? ' · 睡眠设置待恢复' : ''}</div></section>
        <section class="mp-settings-card"><div class="mp-section-title"><div><span class="mp-setting-icon">⌘</span><h2>全局截图快捷键</h2></div></div>
          <label class="mp-setting-row"><span><strong>启用 ⌘ Control A 截图</strong><small>从任何应用触发 macOS 截图工具。</small></span><input type="checkbox" data-setting="screenshotShortcutEnabled" ${s.screenshotShortcutEnabled ? 'checked' : ''}><i class="mp-switch"></i></label>
          <div class="mp-setting-status">${shortcut.registered ? '快捷键已注册' : (shortcut.error || '快捷键未注册')}${s.screenshotDirectory ? ` · 保存到 ${esc(s.screenshotDirectory)}` : ''}${screenshot.error ? ` · ${esc(screenshot.error)}` : ''}${screenshot.screenRecordingPermissionGranted === false ? ' · 首次截图需允许屏幕录制权限' : ''}</div><div class="mp-setting-actions"><button class="mp-secondary-btn" data-action="chooseScreenshotDirectory" data-testid="choose-screenshot-dir">更改截图位置</button><button class="mp-secondary-btn" data-action="openScreenshotDirectory" data-testid="open-screenshot-dir">打开截图位置</button><button class="mp-secondary-btn" data-action="takeScreenshot" data-testid="take-screenshot">立即截图</button>${screenshot.lastSavedPath ? `<small>上次截图：${esc(screenshot.lastSavedPath)}</small>` : ''}</div></section>
        <section class="mp-settings-card"><div class="mp-section-title"><div><span class="mp-setting-icon">${icon('login')}</span><h2>登录时启动</h2></div></div><label class="mp-setting-row"><span><strong>随 macOS 登录启动</strong><small>${esc(loginStatus)}</small></span><input type="checkbox" data-setting="launchAtLogin" data-testid="setting-launchAtLogin" ${launchAtLogin ? 'checked' : ''}><i class="mp-switch"></i></label><div class="mp-setting-actions"><button class="mp-secondary-btn" data-action="openLoginSettings">打开登录项设置</button></div></section>
        <section class="mp-settings-card"><div class="mp-section-title"><div><span class="mp-setting-icon">⌑</span><h2>系统权限</h2></div></div><p class="mp-panel-note">若文件检查或截图受权限限制，可在 macOS 隐私设置中授权。</p><div class="mp-setting-actions"><button class="mp-secondary-btn" data-action="openScreenPermission">屏幕录制权限</button><button class="mp-secondary-btn" data-action="openDiskPermission">完整磁盘访问权限</button></div></section>
        ${data.warnings?.length ? `<div class="mp-inline-error">${data.warnings.map(esc).join('<br>')}</div>` : ''}`;
    } catch (e) { content.innerHTML = `<div class="mp-inline-error">${esc(e.message)}<br>请在桌面应用中使用这些设置。</div>`; }
  }
  async function onSettingsClick(e) {
    const action = e.target.closest('[data-action]')?.dataset.action; if (!action) return;
    try {
      if (action === 'restoreLidSleep') { await request('/api/settings/update', { restoreLidSleep: true }); toast('已恢复合盖睡眠设置。'); await loadSettings(); }
      if (action === 'chooseScreenshotDirectory') { const r = await request('/api/tools/pick-folder'); if (r.path) { await request('/api/settings/update', { screenshotDirectory: r.path }); await loadSettings(); } }
      if (action === 'openScreenshotDirectory') await request('/api/utility/open', { id: 'screenshots-folder' });
      if (action === 'takeScreenshot') { const r = await request('/api/screenshot'); toast(r.path ? `截图已保存：${r.path}` : (r.message || '截图已启动')); }
      if (action === 'openLoginSettings') await openLoginSettings();
      if (action === 'openScreenPermission') await request('/api/settings/open-privacy', { pane: 'screen-recording' });
      if (action === 'openDiskPermission') await request('/api/settings/open-privacy', { pane: 'full-disk-access' });
    } catch (err) { toast(err.message, true); }
  }
  async function onSettingsChange(e) {
    const key = e.target.dataset.setting; if (!key) return;
    const value = e.target.type === 'checkbox' ? e.target.checked : Number(e.target.value);
    if (key === 'lidClosedMode' && value && !await confirmDialog('启用合盖运行', '合盖后 Mac 仍会运行并产生热量。请连接电源并保持通风。你可以随时恢复原有睡眠设置。', '启用')) { e.target.checked = false; return; }
    try {
      const payload = { [key]: value };
      await request('/api/settings/update', payload); await loadSettings(); toast('设置已更新。');
    } catch (err) { toast(err.message, true); await loadSettings(); }
  }

  const handlers = { chooseRoot, startScan, cancelScan, trashSelected, revealItem, selectAllSafe, loadLoginItems, openLoginSettings, openUtility, loadSharing, chooseShareFolder, addShare, removeShare, connectShare, testShare, openSharingSettings, copyShareAddress, returnTools };
  window.addEventListener('DOMContentLoaded', init, { once: true });
})();
