(() => {
  'use strict';

  const params = new URLSearchParams(window.location.search);
  const isNativeApp = Boolean(window.__MACPULSE_NATIVE__) || params.get('native') === '1';
  if (isNativeApp) {
    document.body.classList.add('is-native-app');
  }
  const hostPidParam = params.get('hostPid') || '';

  // State
  const HISTORY_LEN = 90;
  const history = {
    memUsedPct: [],
    memPressure: [],
    cpuTotal: [],
    cpuSys: [],
    gpuUtil: [],
    netRx: [],
    netTx: []
  };

  let latest = null;
  let paused = false;
  let mainTab = 'hardware'; // 'hardware' | 'network'

  // Tab 1 (Hardware & Memory) state
  let viewMode = 'groups'; // 'groups' | 'processes'
  let activeFilter = 'all'; // 'all' | 'reclaim' | 'dev_ai' | 'heavy' | 'cpu'
  let treemapGroupKey = null;
  let searchQuery = '';
  let sortBy = 'mem'; // 'mem' | 'cpu' | 'name'
  let sortAsc = false;
  const selectedKeys = new Set();
  const expandedGroups = new Set();

  // Tab 2 (Global Network & Firewall) state
  let netViewMode = 'apps'; // 'apps' | 'connections'
  let netFilter = 'all'; // 'all' | 'active' | 'heavy' | 'blocked'
  let netSearchQuery = '';
  let mapHubFilter = null; // { label, ips: Set }
  let renderedMapHubs = [];
  let hoveredHub = null;
  let animFrameId = null;
  let animPhase = 0;

  let pendingModalAction = null;
  let es = null;

  const TREE_COLORS = [
    '#2563eb', '#7c3aed', '#0891b2', '#db2777', '#d97706',
    '#059669', '#4f46e5', '#ea580c', '#0284c7', '#475569'
  ];

  // Formatters
  function fmtBytes(bytes, decimals = 2) {
    const b = Number(bytes) || 0;
    if (b <= 0) return '0 B';
    const gb = b / 1073741824;
    if (gb >= 10) return gb.toFixed(1) + ' GB';
    if (gb >= 1) return gb.toFixed(decimals) + ' GB';
    const mb = b / 1048576;
    if (mb >= 10) return Math.round(mb) + ' MB';
    if (mb >= 1) return mb.toFixed(1) + ' MB';
    const kb = b / 1024;
    if (kb >= 1) return Math.round(kb) + ' KB';
    return Math.round(b) + ' B';
  }

  function fmtRate(bps) {
    const v = Number(bps) || 0;
    if (v <= 0) return '0 B/s';
    if (v < 1024) return Math.round(v) + ' B/s';
    if (v < 1048576) return (v / 1024).toFixed(1) + ' KB/s';
    if (v < 1073741824) return (v / 1048576).toFixed(2) + ' MB/s';
    return (v / 1073741824).toFixed(2) + ' GB/s';
  }

  function fmtDuration(sec) {
    const s = Math.max(0, Math.floor(Number(sec) || 0));
    const d = Math.floor(s / 86400);
    const h = Math.floor((s % 86400) / 3600);
    const m = Math.floor((s % 3600) / 60);
    if (d > 0) return `${d}天 ${h}小时`;
    if (h > 0) return `${h}小时 ${m}分`;
    if (m > 0) return `${m}分 ${s % 60}秒`;
    return `${s}秒`;
  }

  function escapeHtml(str) {
    return String(str ?? '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  function pushHist(arr, val) {
    const v = Number(val) || 0;
    if (arr.length === 0) {
      for (let i = 0; i < 16; i++) arr.push(v);
    } else {
      arr.push(v);
    }
    if (arr.length > HISTORY_LEN) arr.shift();
  }

  function showToast(htmlMsg, type = 'success', durationMs = 4800) {
    const stack = document.getElementById('toastStack');
    const el = document.createElement('div');
    el.className = `toast ${type}`;
    el.innerHTML = htmlMsg;
    stack.appendChild(el);
    setTimeout(() => {
      el.style.opacity = '0';
      el.style.transition = 'opacity 0.25s ease';
      setTimeout(() => el.remove(), 260);
    }, durationMs);
  }

  // Unified Transport Adapter (Standalone Native WKWebView Bridge OR HTTP Server)
  async function apiPost(endpoint, payload) {
    if (window.__MACPULSE_NATIVE__ && window.webkit?.messageHandlers?.macpulseApi) {
      const data = await window.webkit.messageHandlers.macpulseApi.postMessage({
        endpoint,
        payload: payload || {}
      });
      if (data && data.ok === false) {
        throw new Error(data.error || '操作未成功');
      }
      return data || {};
    }

    const res = await fetch(endpoint, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-MacPulse-Client': '1'
      },
      body: JSON.stringify(payload || {})
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok || data.ok === false) {
      throw new Error(data.error || `请求失败 (${res.status})`);
    }
    return data;
  }

  // Retina Canvas Streaming Sparkline
  window.macpulseRequest = async (endpoint, payload) => {
    if (!window.__MACPULSE_NATIVE__) throw new Error('请在桌面应用中使用此功能。');
    return apiPost(endpoint, payload);
  };

  function drawStreamChart(canvasId, seriesList, maxFixed = 100) {
    const canvas = document.getElementById(canvasId);
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    if (rect.width <= 0 || rect.height <= 0) return;

    const dpr = window.devicePixelRatio || 1;
    const w = Math.round(rect.width * dpr);
    const h = Math.round(rect.height * dpr);
    if (canvas.width !== w || canvas.height !== h) {
      canvas.width = w;
      canvas.height = h;
    }

    const ctx = canvas.getContext('2d');
    ctx.save();
    ctx.scale(dpr, dpr);
    const cw = rect.width;
    const ch = rect.height;
    ctx.clearRect(0, 0, cw, ch);

    ctx.strokeStyle = 'rgba(51, 65, 85, 0.35)';
    ctx.lineWidth = 1;
    for (const frac of [0.25, 0.5, 0.75]) {
      const y = Math.round(ch * frac) + 0.5;
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(cw, y);
      ctx.stroke();
    }

    let maxVal = maxFixed;
    if (!maxVal || maxVal <= 0) {
      maxVal = 10240;
      for (const s of seriesList) {
        for (const v of s.data) {
          if (v > maxVal) maxVal = v;
        }
      }
      maxVal *= 1.15;
    }

    const padTop = 5;
    const padBottom = 3;
    const usableH = Math.max(10, ch - padTop - padBottom);

    for (const s of seriesList) {
      const pts = s.data;
      if (!pts || pts.length === 0) continue;

      const spanCount = Math.max(2, pts.length);
      const stepX = cw / (spanCount - 1);

      ctx.beginPath();
      let lastX = 0;
      let lastY = ch - padBottom;

      for (let i = 0; i < pts.length; i++) {
        const x = i * stepX;
        const clamped = Math.max(0, Math.min(maxVal, pts[i]));
        const y = padTop + usableH * (1 - clamped / maxVal);
        if (i === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
        lastX = x;
        lastY = y;
      }

      ctx.strokeStyle = s.stroke;
      ctx.lineWidth = s.width || 1.8;
      ctx.lineJoin = 'round';
      ctx.stroke();

      if (s.fillTop) {
        ctx.lineTo(lastX, ch);
        ctx.lineTo(0, ch);
        ctx.closePath();
        const grad = ctx.createLinearGradient(0, 0, 0, ch);
        grad.addColorStop(0, s.fillTop);
        grad.addColorStop(1, 'rgba(0, 0, 0, 0)');
        ctx.fillStyle = grad;
        ctx.fill();
      }

      if (s.pulseDot && pts.length > 0) {
        ctx.beginPath();
        ctx.arc(Math.min(cw - 4, lastX), lastY, 3, 0, Math.PI * 2);
        ctx.fillStyle = s.stroke;
        ctx.fill();
      }
    }

    ctx.restore();
  }

  // ==================== TAB 1 RENDERING ====================
  function renderTopTelemetry(snap) {
    const { cpu, memory, gpu, network, diskIO, volumes, netRadar } = snap;
    const totalGb = Math.round(memory.totalBytes / 1073741824);

    document.getElementById('hwSummary').textContent =
      `${cpu.brand} · ${cpu.totalCores}核 CPU (${cpu.superCores}S+${cpu.perfCores}P) · ${gpu.coreCount || 20}核 GPU · ${totalGb}GB 统一内存 · ${snap.osVersion}`;

    document.getElementById('loadAvgVal').textContent =
      (cpu.loadAvg || [0, 0, 0]).map(n => Number(n).toFixed(2)).join(' / ');
    document.getElementById('procCountVal').textContent =
      `${snap.totalProcessCount}`;
    document.getElementById('uptimeVal').textContent = fmtDuration(snap.uptimeSec);

    if (netRadar) {
      document.getElementById('navNetBadge').textContent = String(netRadar.activeAppCount || 0);
    }

    const tot = Math.max(1, memory.totalBytes);
    const memUsedRatio = (memory.usedBytes / tot) * 100;
    pushHist(history.memUsedPct, memUsedRatio);
    pushHist(history.memPressure, memory.pressurePct);
    pushHist(history.cpuTotal, cpu.totalPct);
    pushHist(history.cpuSys, cpu.sysPct);
    pushHist(history.gpuUtil, gpu.deviceUtilizationPct);
    pushHist(history.netRx, network.rxBytesPerSec);
    pushHist(history.netTx, network.txBytesPerSec);

    if (mainTab !== 'hardware') return;

    // 1. Memory Card
    const usedGb = (memory.usedBytes / 1073741824).toFixed(2);
    document.getElementById('memUsedBig').textContent = usedGb;
    document.getElementById('memTotalUnit').textContent = String(totalGb);
    document.getElementById('memAvailVal').textContent = fmtBytes(memory.availableBytes, 2);

    const pBadge = document.getElementById('memPressureBadge');
    const levelLabel = memory.pressureLevel === 'critical' ? '危急' : (memory.pressureLevel === 'warn' ? '偏高' : '健康');
    pBadge.className = `status-badge ${memory.pressureLevel}`;
    pBadge.textContent = `压力 ${memory.pressurePct}% · ${levelLabel}`;

    document.getElementById('segApp').style.width = `${Math.min(100, (memory.appBytes / tot) * 100).toFixed(1)}%`;
    document.getElementById('segWired').style.width = `${Math.min(100, (memory.wiredBytes / tot) * 100).toFixed(1)}%`;
    document.getElementById('segComp').style.width = `${Math.min(100, (memory.compressedBytes / tot) * 100).toFixed(1)}%`;
    document.getElementById('segCache').style.width = `${Math.min(100, (memory.cachedFilesBytes / tot) * 100).toFixed(1)}%`;

    document.getElementById('legApp').textContent = fmtBytes(memory.appBytes, 1);
    document.getElementById('legWired').textContent = fmtBytes(memory.wiredBytes, 1);
    document.getElementById('legComp').textContent = fmtBytes(memory.compressedBytes, 1);
    document.getElementById('legCache').textContent = fmtBytes(memory.cachedFilesBytes, 1);

    const swapPct = memory.swapTotalBytes > 0
      ? Math.min(100, (memory.swapUsedBytes / memory.swapTotalBytes) * 100)
      : 0;
    document.getElementById('swapText').textContent =
      `${fmtBytes(memory.swapUsedBytes, 2)} / ${fmtBytes(memory.swapTotalBytes, 1)}`;
    document.getElementById('swapFill').style.width = `${swapPct.toFixed(1)}%`;

    // 2. CPU Card
    document.getElementById('cpuCardTitle').textContent = `${cpu.brand} 核心负载`;
    document.getElementById('cpuCoreBadge').textContent = `${cpu.superCores} Super + ${cpu.perfCores} Perf`;
    document.getElementById('cpuTotalBig').textContent = cpu.totalPct.toFixed(1);
    document.getElementById('cpuUserVal').textContent = `${cpu.userPct.toFixed(1)}%`;
    document.getElementById('cpuSysVal').textContent = `${cpu.sysPct.toFixed(1)}%`;

    const matrix = document.getElementById('coreMatrix');
    const cores = cpu.cores || [];
    if (matrix.children.length !== cores.length) {
      matrix.style.gridTemplateColumns = `repeat(${Math.max(1, cores.length)}, minmax(0, 1fr))`;
      matrix.innerHTML = cores.map((c, idx) => {
        const isSuper = c.tier === 'Super';
        const shortLabel = isSuper ? `S${idx + 1}` : `P${idx - cpu.superCores + 1}`;
        return `
          <div class="core-col" title="${c.tier} 核心 #${idx + 1}">
            <div class="core-bar-wrap">
              <div class="core-bar-fill ${isSuper ? 'super' : 'perf'}" style="height:2%"></div>
            </div>
            <span class="core-tag ${isSuper ? 'super' : ''}">${shortLabel}</span>
          </div>
        `;
      }).join('');
    }
    cores.forEach((c, idx) => {
      const col = matrix.children[idx];
      if (!col) return;
      col.title = `${c.tier} 核心 #${idx + 1}: ${c.totalPct.toFixed(1)}% (用户 ${c.userPct.toFixed(1)}% / 内核 ${c.sysPct.toFixed(1)}%)`;
      const fill = col.querySelector('.core-bar-fill');
      if (fill) {
        fill.style.height = `${Math.max(3, Math.min(100, c.totalPct))}%`;
        const isSuper = c.tier === 'Super';
        fill.className = `core-bar-fill ${c.totalPct >= 88 ? 'hot' : (isSuper ? 'super' : 'perf')}`;
      }
    });

    // 3. GPU Card
    document.getElementById('gpuCoreBadge').textContent = gpu.coreCount ? `${gpu.coreCount} 核 Metal` : 'Apple GPU';
    document.getElementById('gpuUtilBig').textContent = String(gpu.deviceUtilizationPct);
    document.getElementById('gpuRenderVal').textContent = `${gpu.rendererUtilizationPct}%`;
    document.getElementById('gpuTilerVal').textContent = `${gpu.tilerUtilizationPct}%`;
    document.getElementById('gpuMemInUse').textContent = fmtBytes(gpu.inUseMemoryBytes, 2);
    document.getElementById('gpuMemAlloc').textContent = fmtBytes(gpu.allocMemoryBytes, 1);

    const vramPct = Math.min(100, (gpu.inUseMemoryBytes / tot) * 100);
    document.getElementById('gpuVramFill').style.width = `${vramPct.toFixed(1)}%`;

    const ollamaBox = document.getElementById('ollamaBox');
    const models = snap.ollamaModels || [];
    if (models.length > 0) {
      const names = models.map(m => `${m.name} (${m.size})`).join(', ');
      ollamaBox.innerHTML = `
        <span class="muted-note" title="${escapeHtml(names)}">Ollama 驻留: <b class="text-amber">${escapeHtml(names)}</b></span>
        <button type="button" class="row-btn kill" id="btnStopOllama">卸载显存</button>
      `;
      const btn = document.getElementById('btnStopOllama');
      if (btn) {
        btn.onclick = async () => {
          btn.disabled = true;
          btn.textContent = '卸载中…';
          try {
            const res = await apiPost('/api/ollama-stop', { model: '*' });
            showToast(`已卸载 Ollama 驻留模型 (${escapeHtml((res.stopped || []).join(', '))})，系统可用内存释放 <b>${fmtBytes(res.systemFreedBytes)}</b>`);
          } catch (e) {
            showToast(escapeHtml(e.message), 'error');
          }
        };
      }
    } else {
      const savedRatio = memory.uncompressedInCompressorBytes > memory.compressedBytes
        ? fmtBytes(memory.uncompressedInCompressorBytes - memory.compressedBytes, 1)
        : '0 B';
      ollamaBox.innerHTML = `<span class="muted-note">内存压缩器已为您节省物理空间 <b class="text-purple mono">${savedRatio}</b></span>`;
    }

    // 4. Network, Disk IO & Volumes
    document.getElementById('netRxVal').textContent = fmtRate(network.rxBytesPerSec);
    document.getElementById('netTxVal').textContent = fmtRate(network.txBytesPerSec);
    document.getElementById('diskReadVal').textContent = fmtRate(diskIO.readBytesPerSec);
    document.getElementById('diskWriteVal').textContent = fmtRate(diskIO.writeBytesPerSec);
    const totalIoRate = (network.rxBytesPerSec || 0) + (network.txBytesPerSec || 0) + (diskIO.readBytesPerSec || 0) + (diskIO.writeBytesPerSec || 0);
    document.getElementById('ioTotalBadge').textContent = `总吞吐 ${fmtRate(totalIoRate)}`;

    const volList = document.getElementById('volumesList');
    volList.innerHTML = (volumes || []).slice(0, 2).map(v => `
      <div class="vol-item">
        <div class="vol-row">
          <span>${escapeHtml(v.name)}</span>
          <span class="mono">剩余 <b>${fmtBytes(v.availableBytes, 1)}</b> / ${fmtBytes(v.totalBytes, 0)}</span>
        </div>
        <div class="mini-progress">
          <div class="mini-fill ${v.usedPct > 88 ? 'fill-amber' : 'fill-cyan'}" style="width:${Math.min(100, v.usedPct)}%"></div>
        </div>
      </div>
    `).join('');

    drawStreamChart('chartMem', [
      { data: history.memUsedPct, stroke: '#10b981', fillTop: 'rgba(16, 185, 129, 0.28)', pulseDot: true },
      { data: history.memPressure, stroke: '#f59e0b', width: 1.3 }
    ], 100);

    drawStreamChart('chartCpu', [
      { data: history.cpuTotal, stroke: '#3b82f6', fillTop: 'rgba(59, 130, 246, 0.30)', pulseDot: true },
      { data: history.cpuSys, stroke: '#06b6d4', fillTop: 'rgba(6, 182, 212, 0.18)', width: 1.3 }
    ], 100);

    drawStreamChart('chartGpu', [
      { data: history.gpuUtil, stroke: '#a855f7', fillTop: 'rgba(168, 85, 247, 0.32)', pulseDot: true }
    ], 100);

    drawStreamChart('chartNet', [
      { data: history.netRx, stroke: '#06b6d4', fillTop: 'rgba(6, 182, 212, 0.25)', pulseDot: true },
      { data: history.netTx, stroke: '#3b82f6', width: 1.4 }
    ], 0);
  }

  function renderTreemap(snap) {
    if (mainTab !== 'hardware') return;
    const bar = document.getElementById('treemapBar');
    const clearBtn = document.getElementById('btnClearGroupFilter');
    clearBtn.classList.toggle('hidden', !treemapGroupKey);

    const groups = snap.appGroups || [];
    const totalMem = Math.max(1, snap.memory.totalBytes);
    const top9 = groups.slice(0, 9);

    let sumTop = 0;
    const blocks = top9.map((g, i) => {
      sumTop += g.totalFootprintBytes;
      const pct = Math.max(2.5, (g.totalFootprintBytes / totalMem) * 100);
      return {
        key: g.groupKey,
        name: g.appName,
        bytes: g.totalFootprintBytes,
        pct,
        color: TREE_COLORS[i % TREE_COLORS.length]
      };
    });

    const otherUsed = Math.max(0, snap.memory.usedBytes - sumTop);
    if (otherUsed > 512 * 1048576) {
      blocks.push({
        key: '__other__',
        name: '内核与其他缓冲',
        bytes: otherUsed,
        pct: Math.max(3, (otherUsed / totalMem) * 100),
        color: '#334155'
      });
    }

    bar.innerHTML = blocks.map(b => {
      const isSelected = treemapGroupKey && treemapGroupKey === b.key;
      const clickable = b.key !== '__other__';
      return `
        <button type="button"
          class="tree-block ${isSelected ? 'active-filter' : ''}"
          style="flex-grow:${b.pct.toFixed(2)}; background:${b.color}; ${clickable ? '' : 'cursor:default;'}"
          data-group-key="${escapeHtml(b.key)}"
          title="${escapeHtml(b.name)} · 占用 ${fmtBytes(b.bytes, 2)}">
          <span class="tree-name">${escapeHtml(b.name)}</span>
          <span class="tree-size">${fmtBytes(b.bytes, 1)}</span>
        </button>
      `;
    }).join('');

    bar.querySelectorAll('.tree-block').forEach(btn => {
      const key = btn.getAttribute('data-group-key');
      if (!key || key === '__other__') return;
      btn.onclick = () => {
        treemapGroupKey = (treemapGroupKey === key) ? null : key;
        renderTable(latest);
        renderTreemap(latest);
      };
    });
  }

  function isGroupReclaimable(group, procByPid) {
    if (group.safetyTier !== 'safe') return false;
    if (group.totalFootprintBytes >= 450 * 1048576 && group.totalCpuPct < 0.25) return true;
    return group.pids.some(pid => {
      const p = procByPid.get(pid);
      return p && Boolean(p.reclaimHint);
    });
  }

  function renderTierBadge(safetyTier, isReclaim) {
    if (safetyTier === 'system') {
      return `<span class="tier-badge tier-system" title="macOS 核心服务，禁止终止">系统保护</span>`;
    }
    if (safetyTier === 'session') {
      return `<span class="tier-badge tier-session" title="当前工作台、活跃 AI 会话或 GPU 训练任务，默认排除自动清理">工作台/训练保护</span>`;
    }
    if (isReclaim) {
      return `<span class="tier-badge tier-reclaim" title="长时间低 CPU 且占用较高内存，可安全回收">闲置可回收</span>`;
    }
    return `<span class="tier-badge tier-safe">安全可控</span>`;
  }

  function getFilteredItems(snap) {
    const procByPid = new Map();
    for (const p of (snap.topProcesses || [])) {
      procByPid.set(p.pid, p);
    }

    let reclaimTotal = 0;
    for (const g of (snap.appGroups || [])) {
      if (isGroupReclaimable(g, procByPid)) reclaimTotal++;
    }
    document.getElementById('reclaimCount').textContent = String(reclaimTotal);

    const q = searchQuery.trim().toLowerCase();

    if (viewMode === 'groups') {
      const list = (snap.appGroups || []).filter(g => {
        if (treemapGroupKey && g.groupKey !== treemapGroupKey) return false;
        if (activeFilter === 'reclaim' && !isGroupReclaimable(g, procByPid)) return false;
        if (activeFilter === 'dev_ai' && !(g.category.includes('AI') || g.category.includes('开发'))) return false;
        if (activeFilter === 'heavy' && g.totalFootprintBytes < 500 * 1048576) return false;
        if (activeFilter === 'cpu' && g.totalCpuPct < 3.0) return false;
        if (q) {
          const hay = `${g.appName} ${g.category} ${(g.projectHints || []).join(' ')} ${g.pids.join(' ')}`.toLowerCase();
          if (!hay.includes(q)) return false;
        }
        return true;
      });

      list.sort((a, b) => {
        let cmp = 0;
        if (sortBy === 'cpu') cmp = b.totalCpuPct - a.totalCpuPct;
        else if (sortBy === 'name') cmp = a.appName.localeCompare(b.appName, 'zh-CN');
        else cmp = b.totalFootprintBytes - a.totalFootprintBytes;
        return sortAsc ? -cmp : cmp;
      });
      return { mode: 'groups', list, procByPid };
    } else {
      const list = (snap.topProcesses || []).filter(p => {
        if (treemapGroupKey && p.groupKey !== treemapGroupKey) return false;
        if (activeFilter === 'reclaim' && !p.reclaimHint) return false;
        if (activeFilter === 'dev_ai') {
          const k = p.groupKey;
          if (!(k.startsWith('ai:') || k.startsWith('dev:') || k.startsWith('build:'))) return false;
        }
        if (activeFilter === 'heavy' && p.footprintBytes < 500 * 1048576) return false;
        if (activeFilter === 'cpu' && p.cpuPct < 3.0) return false;
        if (q) {
          const hay = `${p.name} ${p.appName} ${p.projectHint} ${p.pid} ${p.commandLine}`.toLowerCase();
          if (!hay.includes(q)) return false;
        }
        return true;
      });

      list.sort((a, b) => {
        let cmp = 0;
        if (sortBy === 'cpu') cmp = b.cpuPct - a.cpuPct;
        else if (sortBy === 'name') cmp = a.name.localeCompare(b.name, 'zh-CN');
        else cmp = b.footprintBytes - a.footprintBytes;
        return sortAsc ? -cmp : cmp;
      });
      return { mode: 'processes', list, procByPid };
    }
  }

  function resolveSelectedTargets(snap) {
    if (!snap || selectedKeys.size === 0) return { pids: [], estBytes: 0, labels: [], hasSession: false };
    const pidSet = new Set();
    let estBytes = 0;
    const labels = [];
    let hasSession = false;

    const procByPid = new Map((snap.topProcesses || []).map(p => [p.pid, p]));
    const groupByKey = new Map((snap.appGroups || []).map(g => [g.groupKey, g]));

    for (const key of selectedKeys) {
      if (key.startsWith('pid:')) {
        const pid = Number(key.slice(4));
        const p = procByPid.get(pid);
        if (p && p.safetyTier !== 'system') {
          if (!pidSet.has(pid)) {
            pidSet.add(pid);
            estBytes += p.footprintBytes;
          }
          if (p.safetyTier === 'session') hasSession = true;
          labels.push(`[PID ${p.pid}] ${p.name}${p.projectHint ? ' (' + p.projectHint + ')' : ''} — ${fmtBytes(p.footprintBytes)}`);
        }
      } else {
        const g = groupByKey.get(key);
        if (g && g.safetyTier !== 'system') {
          for (const pid of g.pids) pidSet.add(pid);
          estBytes += g.totalFootprintBytes;
          if (g.safetyTier === 'session') hasSession = true;
          labels.push(`${g.appName} (${g.processCount} 个子进程) — ${fmtBytes(g.totalFootprintBytes)}`);
        }
      }
    }

    return { pids: Array.from(pidSet), estBytes, labels, hasSession };
  }

  function updateBulkBar(snap) {
    const bulkBar = document.getElementById('bulkBar');
    const info = resolveSelectedTargets(snap);
    if (info.pids.length === 0) {
      bulkBar.classList.add('hidden');
      return;
    }
    bulkBar.classList.remove('hidden');
    document.getElementById('bulkCountBadge').textContent = `已选 ${selectedKeys.size} 项 (${info.pids.length} 进程)`;
    document.getElementById('bulkEstMem').textContent = fmtBytes(info.estBytes, 2);
  }

  function renderTable(snap) {
    if (!snap || mainTab !== 'hardware') return;
    const tbody = document.getElementById('procTableBody');
    const totalMem = Math.max(1, snap.memory.totalBytes);
    const { mode, list, procByPid } = getFilteredItems(snap);

    const validGroupKeys = new Set((snap.appGroups || []).map(g => g.groupKey));
    const validPidKeys = new Set((snap.topProcesses || []).map(p => `pid:${p.pid}`));
    for (const k of Array.from(selectedKeys)) {
      if (k.startsWith('pid:')) {
        if (!validPidKeys.has(k)) selectedKeys.delete(k);
      } else if (!validGroupKeys.has(k)) {
        selectedKeys.delete(k);
      }
    }

    updateBulkBar(snap);

    if (list.length === 0) {
      tbody.innerHTML = `<tr><td colspan="7" class="empty-cell">当前筛选条件下没有匹配的进程或应用</td></tr>`;
      return;
    }

    const rowsHtml = [];

    if (mode === 'groups') {
      for (const g of list) {
        const isChecked = selectedKeys.has(g.groupKey);
        const canKill = g.safetyTier !== 'system';
        const isReclaim = isGroupReclaimable(g, procByPid);
        const memRatio = Math.min(100, (g.totalFootprintBytes / totalMem) * 100);
        const barColor = memRatio > 12 ? '#ef4444' : (memRatio > 5 ? '#f59e0b' : '#3b82f6');
        const isExpanded = expandedGroups.has(g.groupKey);

        const hintsHtml = (g.projectHints || []).slice(0, 3)
          .map(h => `<span class="project-badge">${escapeHtml(h)}</span>`)
          .join('');

        rowsHtml.push(`
          <tr class="${isChecked ? 'row-selected' : ''}" data-row-group="${escapeHtml(g.groupKey)}">
            <td class="col-check">
              ${canKill
                ? `<input type="checkbox" class="row-check" data-sel-key="${escapeHtml(g.groupKey)}" ${isChecked ? 'checked' : ''} aria-label="选择 ${escapeHtml(g.appName)}" />`
                : `<span class="lock-tag" title="系统保护">锁</span>`}
            </td>
            <td>
              <div class="proc-main-cell">
                <div class="proc-title-line">
                  ${g.processCount > 1
                    ? `<button type="button" class="expand-btn" data-expand-group="${escapeHtml(g.groupKey)}" title="展开查看子进程明细">${isExpanded ? '−' : '+'}</button>`
                    : ''}
                  <span class="proc-name">${escapeHtml(g.appName)}</span>
                  <span class="cat-badge">${escapeHtml(g.category)}</span>
                  ${hintsHtml}
                </div>
                <span class="proc-subline mono">主进程 PID ${g.leadPid} · 共涵盖 ${g.processCount} 个关联进程</span>
              </div>
            </td>
            <td>${renderTierBadge(g.safetyTier, isReclaim)}</td>
            <td>
              <div class="mem-cell-wrap mono">
                <div class="mem-cell-top">
                  <span class="mem-bytes">${fmtBytes(g.totalFootprintBytes, 2)}</span>
                  <span class="mem-pct">${memRatio.toFixed(1)}%</span>
                </div>
                <div class="row-bar">
                  <div class="row-bar-fill" style="width:${Math.max(2, memRatio * 2.2).toFixed(1)}%; background:${barColor}"></div>
                </div>
              </div>
            </td>
            <td class="mono ${g.totalCpuPct >= 50 ? 'text-amber' : ''}"><b>${g.totalCpuPct.toFixed(1)}%</b></td>
            <td class="mono text-secondary">${g.processCount} 个进程</td>
            <td class="col-actions">
              ${canKill ? `
                <div class="row-actions">
                  <button type="button" class="row-btn term" data-act="term-group" data-key="${escapeHtml(g.groupKey)}">结束</button>
                  <button type="button" class="row-btn kill" data-act="kill-group" data-key="${escapeHtml(g.groupKey)}">强杀回收</button>
                </div>
              ` : `<span class="lock-tag">受系统保护</span>`}
            </td>
          </tr>
        `);

        if (isExpanded) {
          const children = g.pids
            .map(pid => procByPid.get(pid))
            .filter(Boolean)
            .sort((a, b) => b.footprintBytes - a.footprintBytes);

          for (const p of children) {
            const pRatio = Math.min(100, (p.footprintBytes / totalMem) * 100);
            const pCanKill = p.safetyTier !== 'system';
            rowsHtml.push(`
              <tr class="child-row">
                <td class="col-check"></td>
                <td>
                  <div class="proc-main-cell" style="padding-left:24px;">
                    <div class="proc-title-line">
                      <span class="mono text-secondary">↳ [${p.pid}]</span>
                      <span class="proc-name" style="font-size:12.5px;">${escapeHtml(p.name)}</span>
                      ${p.projectHint ? `<span class="project-badge">${escapeHtml(p.projectHint)}</span>` : ''}
                    </div>
                    ${p.commandLine ? `<span class="proc-subline mono" title="${escapeHtml(p.commandLine)}">${escapeHtml(p.commandLine)}</span>` : ''}
                  </div>
                </td>
                <td>${renderTierBadge(p.safetyTier, Boolean(p.reclaimHint))}</td>
                <td class="mono">${fmtBytes(p.footprintBytes, 2)} <span class="mem-pct">(${pRatio.toFixed(1)}%)</span></td>
                <td class="mono">${p.cpuPct.toFixed(1)}%</td>
                <td class="mono text-secondary">${fmtDuration(p.uptimeSec)}</td>
                <td class="col-actions">
                  ${pCanKill ? `
                    <div class="row-actions">
                      <button type="button" class="row-btn term" data-act="term-pid" data-pid="${p.pid}">结束</button>
                      <button type="button" class="row-btn kill" data-act="kill-pid" data-pid="${p.pid}">强杀</button>
                    </div>
                  ` : ''}
                </td>
              </tr>
            `);
          }
        }
      }
    } else {
      for (const p of list) {
        const selKey = `pid:${p.pid}`;
        const isChecked = selectedKeys.has(selKey);
        const canKill = p.safetyTier !== 'system';
        const memRatio = Math.min(100, (p.footprintBytes / totalMem) * 100);
        const barColor = memRatio > 10 ? '#ef4444' : (memRatio > 4 ? '#f59e0b' : '#3b82f6');

        rowsHtml.push(`
          <tr class="${isChecked ? 'row-selected' : ''}">
            <td class="col-check">
              ${canKill
                ? `<input type="checkbox" class="row-check" data-sel-key="${selKey}" ${isChecked ? 'checked' : ''} aria-label="选择 PID ${p.pid}" />`
                : `<span class="lock-tag">锁</span>`}
            </td>
            <td>
              <div class="proc-main-cell">
                <div class="proc-title-line">
                  <span class="mono text-secondary">[${p.pid}]</span>
                  <span class="proc-name">${escapeHtml(p.name)}</span>
                  ${p.appName && p.appName !== p.name ? `<span class="cat-badge">${escapeHtml(p.appName)}</span>` : ''}
                  ${p.projectHint ? `<span class="project-badge">${escapeHtml(p.projectHint)}</span>` : ''}
                </div>
                <span class="proc-subline mono" title="${escapeHtml(p.commandLine || p.execPath)}">${escapeHtml(p.commandLine || p.execPath || '--')}</span>
              </div>
            </td>
            <td>${renderTierBadge(p.safetyTier, Boolean(p.reclaimHint))}</td>
            <td>
              <div class="mem-cell-wrap mono">
                <div class="mem-cell-top">
                  <span class="mem-bytes">${fmtBytes(p.footprintBytes, 2)}</span>
                  <span class="mem-pct">${memRatio.toFixed(1)}%</span>
                </div>
                <div class="row-bar">
                  <div class="row-bar-fill" style="width:${Math.max(2, memRatio * 2.4).toFixed(1)}%; background:${barColor}"></div>
                </div>
              </div>
            </td>
            <td class="mono ${p.cpuPct >= 50 ? 'text-amber' : ''}"><b>${p.cpuPct.toFixed(1)}%</b></td>
            <td class="mono text-secondary">${p.state} · ${fmtDuration(p.uptimeSec)}</td>
            <td class="col-actions">
              ${canKill ? `
                <div class="row-actions">
                  <button type="button" class="row-btn term" data-act="term-pid" data-pid="${p.pid}">结束</button>
                  <button type="button" class="row-btn kill" data-act="kill-pid" data-pid="${p.pid}">强杀回收</button>
                </div>
              ` : `<span class="lock-tag">受系统保护</span>`}
            </td>
          </tr>
        `);
      }
    }

    tbody.innerHTML = rowsHtml.join('');
  }

  // ==================== TAB 2: WORLD MAP, FIREWALL & NETWORK APPS ====================
  let staticMapLayerCanvas = null;
  let staticMapLayerKey = '';

  function projectLonLat(lon, lat, width, height) {
    const minLat = -58;
    const maxLat = 81;
    const clampedLat = Math.max(minLat, Math.min(maxLat, Number(lat) || 0));
    // Robinson-inspired / Natural Earth pseudo-cylindrical aspect with gentle high-latitude compression
    const rad = (clampedLat * Math.PI) / 180;
    const mercY = Math.log(Math.tan(Math.PI / 4 + (rad * 0.72) / 2));
    const maxMerc = Math.log(Math.tan(Math.PI / 4 + ((maxLat * Math.PI) / 180 * 0.72) / 2));
    const minMerc = Math.log(Math.tan(Math.PI / 4 + ((minLat * Math.PI) / 180 * 0.72) / 2));
    const normX = ((Number(lon) || 0) + 180) / 360;
    const normY = (maxMerc - mercY) / (maxMerc - minMerc);
    const padX = 14;
    const padY = 12;
    return {
      x: padX + normX * (width - padX * 2),
      y: padY + normY * (height - padY * 2)
    };
  }

  function traceProjectedRings(ctx, rings, cw, ch) {
    for (const ring of rings) {
      if (!ring || ring.length < 3) continue;
      let started = false;
      for (let i = 0; i < ring.length; i++) {
        const lon = ring[i][0];
        const lat = ring[i][1];
        if (i > 0 && Math.abs(lon - ring[i - 1][0]) > 150) {
          started = false;
        }
        const p = projectLonLat(lon, lat, cw, ch);
        if (!started) {
          ctx.moveTo(p.x, p.y);
          started = true;
        } else {
          ctx.lineTo(p.x, p.y);
        }
      }
      ctx.closePath();
    }
  }

  function getStaticWorldMapCanvas(w, h, cw, ch, dpr) {
    const key = `${w}x${h}@${dpr}`;
    if (staticMapLayerCanvas && staticMapLayerKey === key) {
      return staticMapLayerCanvas;
    }
    const off = document.createElement('canvas');
    off.width = w;
    off.height = h;
    const octx = off.getContext('2d');
    octx.save();
    octx.scale(dpr, dpr);

    // 1. Deep Bathymetric Ocean Backdrop
    const oceanGrad = octx.createRadialGradient(cw * 0.48, ch * 0.44, ch * 0.06, cw * 0.5, ch * 0.5, Math.max(cw, ch) * 0.72);
    oceanGrad.addColorStop(0, '#091324');
    oceanGrad.addColorStop(0.55, '#060c18');
    oceanGrad.addColorStop(1, '#04070f');
    octx.fillStyle = oceanGrad;
    octx.fillRect(0, 0, cw, ch);

    // 2. Precision Cartographic Graticule & Degree Ticks
    octx.lineWidth = 0.75;
    for (let lon = -150; lon <= 150; lon += 30) {
      const pTop = projectLonLat(lon, 78, cw, ch);
      const pBot = projectLonLat(lon, -55, cw, ch);
      octx.strokeStyle = lon === 0 ? 'rgba(56, 189, 248, 0.16)' : 'rgba(30, 41, 59, 0.42)';
      octx.beginPath();
      octx.moveTo(Math.round(pTop.x) + 0.5, pTop.y);
      octx.lineTo(Math.round(pBot.x) + 0.5, pBot.y);
      octx.stroke();
    }
    for (const lat of [-45, -23.44, 0, 23.44, 45, 66.56]) {
      const pL = projectLonLat(-179, lat, cw, ch);
      const pR = projectLonLat(179, lat, cw, ch);
      const isEquator = lat === 0;
      const isTropicOrPolar = Math.abs(lat) === 23.44 || Math.abs(lat) === 66.56;
      octx.save();
      if (isTropicOrPolar) octx.setLineDash([3, 4]);
      octx.strokeStyle = isEquator
        ? 'rgba(56, 189, 248, 0.22)'
        : (isTropicOrPolar ? 'rgba(51, 65, 85, 0.36)' : 'rgba(30, 41, 59, 0.42)');
      octx.beginPath();
      octx.moveTo(pL.x, Math.round(pL.y) + 0.5);
      octx.lineTo(pR.x, Math.round(pR.y) + 0.5);
      octx.stroke();
      octx.restore();
    }

    const atlas = typeof window.getRealWorldAtlas === 'function' ? window.getRealWorldAtlas() : null;
    if (atlas && atlas.landRings && atlas.landRings.length > 0) {
      // 3. Continental Shelf Coastal Glow + Landmass Fill (1:50m Natural Earth)
      const landGrad = octx.createLinearGradient(0, ch * 0.08, 0, ch * 0.92);
      landGrad.addColorStop(0, '#16243b');
      landGrad.addColorStop(0.48, '#111d31');
      landGrad.addColorStop(1, '#0d1728');

      octx.save();
      octx.beginPath();
      traceProjectedRings(octx, atlas.landRings, cw, ch);
      octx.shadowColor = 'rgba(14, 165, 233, 0.22)';
      octx.shadowBlur = 9;
      octx.fillStyle = landGrad;
      octx.fill('nonzero');
      octx.restore();

      // Subtle micro-dot / scanline topographic texture clipped inside landmasses
      octx.save();
      octx.beginPath();
      traceProjectedRings(octx, atlas.landRings, cw, ch);
      octx.clip('nonzero');
      octx.fillStyle = 'rgba(148, 163, 184, 0.045)';
      for (let y = 10; y < ch; y += 5) {
        const shift = (y % 10 === 0) ? 2.5 : 0;
        for (let x = 10 + shift; x < cw; x += 5) {
          octx.fillRect(x, y, 1, 1);
        }
      }
      octx.restore();

      // 4. Major Inland Lakes (Great Lakes, Caspian, Victoria, Baikal, etc.) carved back to ocean tone
      if (atlas.lakeRings && atlas.lakeRings.length > 0) {
        octx.save();
        octx.beginPath();
        traceProjectedRings(octx, atlas.lakeRings, cw, ch);
        octx.fillStyle = '#070e1c';
        octx.fill();
        octx.strokeStyle = 'rgba(56, 189, 248, 0.24)';
        octx.lineWidth = 0.55;
        octx.stroke();
        octx.restore();
      }

      // 5. Crisp Sovereign Country Borders (1:50m internal shared arcs)
      if (atlas.borderLines && atlas.borderLines.length > 0) {
        octx.save();
        octx.beginPath();
        for (const arc of atlas.borderLines) {
          if (!arc || arc.length < 2) continue;
          for (let i = 0; i < arc.length; i++) {
            const p = projectLonLat(arc[i][0], arc[i][1], cw, ch);
            if (i === 0) octx.moveTo(p.x, p.y);
            else octx.lineTo(p.x, p.y);
          }
        }
        octx.strokeStyle = 'rgba(100, 116, 139, 0.34)';
        octx.lineWidth = 0.55;
        octx.stroke();
        octx.restore();
      }

      // 6. Precision Coastline Rim Highlight
      octx.save();
      octx.beginPath();
      traceProjectedRings(octx, atlas.landRings, cw, ch);
      octx.strokeStyle = 'rgba(56, 189, 248, 0.44)';
      octx.lineWidth = 0.85;
      octx.lineJoin = 'round';
      octx.stroke();
      octx.restore();
    }

    // 7. Subtle Coordinate Frame Ticks & Vignette
    octx.font = '500 9.5px ui-monospace, SFMono-Regular, Menlo, monospace';
    octx.fillStyle = 'rgba(100, 116, 139, 0.52)';
    for (const [lon, lbl] of [[-120, '120°W'], [-60, '60°W'], [0, '0°'], [60, '60°E'], [120, '120°E']]) {
      const pt = projectLonLat(lon, -55.5, cw, ch);
      octx.fillText(lbl, pt.x - 14, ch - 4);
    }
    for (const [lat, lbl] of [[60, '60°N'], [30, '30°N'], [0, 'EQ'], [-30, '30°S']]) {
      const pt = projectLonLat(-177, lat, cw, ch);
      octx.fillText(lbl, 6, pt.y + 3);
    }

    octx.restore();
    staticMapLayerCanvas = off;
    staticMapLayerKey = key;
    return off;
  }

  function quadBezierPoint(p0, p1, p2, t) {
    const u = 1 - t;
    return {
      x: u * u * p0.x + 2 * u * t * p1.x + t * t * p2.x,
      y: u * u * p0.y + 2 * u * t * p1.y + t * t * p2.y
    };
  }

  function buildMapHubs(radar) {
    const hubMap = new Map();
    for (const c of (radar.connections || [])) {
      if (c.lat === 0 && c.lon === 0) continue;
      // Group nearby servers within ~1.5 degrees into clean visual city hubs
      const key = `${Math.round(c.lat * 0.7)}:${Math.round(c.lon * 0.7)}`;
      let h = hubMap.get(key);
      if (!h) {
        h = {
          key,
          lat: c.lat,
          lon: c.lon,
          city: c.city || '',
          country: c.country || '',
          countryCode: c.countryCode || '',
          rxBps: 0,
          txBps: 0,
          connCount: 0,
          blockedCount: 0,
          apps: new Set(),
          domains: new Set(),
          orgs: new Set(),
          ips: new Set()
        };
        hubMap.set(key, h);
      }
      if (!h.city && c.city) h.city = c.city;
      if (!h.countryCode && c.countryCode) h.countryCode = c.countryCode;
      h.rxBps += (c.rxBps || 0);
      h.txBps += (c.txBps || 0);
      h.connCount += 1;
      if (c.isBlocked) h.blockedCount += 1;
      h.apps.add(c.appName || c.processName);
      if (c.domain) h.domains.add(c.domain);
      if (c.org && c.org !== '解析中…') h.orgs.add(c.org);
      h.ips.add(c.remoteIp);
    }
    return Array.from(hubMap.values()).sort((a, b) => {
      const rateDiff = (b.rxBps + b.txBps) - (a.rxBps + a.txBps);
      if (Math.abs(rateDiff) > 10) return rateDiff;
      return b.connCount - a.connCount;
    });
  }

  function drawWorldMap(snap) {
    if (!snap || !snap.netRadar || mainTab !== 'network') return;
    const canvas = document.getElementById('worldMapCanvas');
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    if (rect.width <= 0 || rect.height <= 0) return;

    const dpr = window.devicePixelRatio || 1;
    const w = Math.round(rect.width * dpr);
    const h = Math.round(rect.height * dpr);
    if (canvas.width !== w || canvas.height !== h) {
      canvas.width = w;
      canvas.height = h;
    }

    const ctx = canvas.getContext('2d');
    ctx.save();
    ctx.clearRect(0, 0, w, h);

    // 1. Blit pre-rendered Retina 1:50m Natural Earth World Base Map (Ocean + Graticule + Land + Lakes + Borders)
    const cw = rect.width;
    const ch = rect.height;
    const baseLayer = getStaticWorldMapCanvas(w, h, cw, ch, dpr);
    ctx.drawImage(baseLayer, 0, 0);

    ctx.scale(dpr, dpr);

    const radar = snap.netRadar;
    const originPt = projectLonLat(radar.originLon || -79.3832, radar.originLat || 43.6532, cw, ch);
    const hubs = buildMapHubs(radar);
    renderedMapHubs = [];

    // 2. Subtle Sovereign Country Highlight for Active Destination Countries
    const atlas = typeof window.getRealWorldAtlas === 'function' ? window.getRealWorldAtlas() : null;
    if (atlas && atlas.countriesByIso) {
      const activeCountryRates = new Map();
      const blockedCountries = new Set();
      for (const h of hubs) {
        if (!h.countryCode) continue;
        const iso = h.countryCode.toUpperCase();
        const prev = activeCountryRates.get(iso) || 0;
        activeCountryRates.set(iso, prev + h.rxBps + h.txBps + 1);
        if (h.blockedCount > 0 && h.blockedCount >= h.connCount) {
          blockedCountries.add(iso);
        }
      }
      for (const [iso, score] of activeCountryRates.entries()) {
        const cEntry = atlas.countriesByIso.get(iso);
        if (!cEntry || !cEntry.rings || cEntry.rings.length === 0) continue;
        ctx.save();
        ctx.beginPath();
        traceProjectedRings(ctx, cEntry.rings, cw, ch);
        if (blockedCountries.has(iso)) {
          ctx.fillStyle = 'rgba(239, 68, 68, 0.11)';
          ctx.strokeStyle = 'rgba(248, 113, 113, 0.42)';
        } else if (score > 1024) {
          ctx.fillStyle = 'rgba(34, 211, 238, 0.09)';
          ctx.strokeStyle = 'rgba(56, 189, 248, 0.46)';
        } else {
          ctx.fillStyle = 'rgba(56, 189, 248, 0.045)';
          ctx.strokeStyle = 'rgba(56, 189, 248, 0.28)';
        }
        ctx.lineWidth = 0.8;
        ctx.fill('nonzero');
        ctx.stroke();
        ctx.restore();
      }
    }

    // 3. Great-Circle-Inspired Geodesic Flight Arcs & Flowing Bandwidth Particles
    for (const hub of hubs) {
      const destPt = projectLonLat(hub.lon, hub.lat, cw, ch);
      const dx = destPt.x - originPt.x;
      const dy = destPt.y - originPt.y;
      const dist = Math.hypot(dx, dy);
      const arcLift = Math.min(82, Math.max(14, dist * 0.21));
      const ctrlPt = {
        x: (originPt.x + destPt.x) / 2,
        y: Math.min(originPt.y, destPt.y) - arcLift
      };

      const totalRate = hub.rxBps + hub.txBps;
      const isAllBlocked = hub.blockedCount > 0 && hub.blockedCount >= hub.connCount;
      const isActive = totalRate >= 64;
      const isSelected = mapHubFilter && mapHubFilter.key === hub.key;

      // Ground shadow under active geodesic arc for 3D depth
      if ((isActive || isSelected) && dist > 18) {
        ctx.save();
        ctx.beginPath();
        ctx.moveTo(originPt.x, originPt.y);
        ctx.lineTo(destPt.x, destPt.y);
        ctx.strokeStyle = 'rgba(2, 6, 23, 0.45)';
        ctx.lineWidth = 1.2;
        ctx.stroke();
        ctx.restore();
      }

      ctx.save();
      ctx.beginPath();
      ctx.moveTo(originPt.x, originPt.y);
      ctx.quadraticCurveTo(ctrlPt.x, ctrlPt.y, destPt.x, destPt.y);

      if (isAllBlocked) {
        ctx.setLineDash([4, 4]);
        ctx.strokeStyle = 'rgba(239, 68, 68, 0.82)';
        ctx.lineWidth = 1.5;
      } else if (isActive || isSelected) {
        const grad = ctx.createLinearGradient(originPt.x, originPt.y, destPt.x, destPt.y);
        grad.addColorStop(0, 'rgba(16, 185, 129, 0.88)');
        grad.addColorStop(0.55, 'rgba(34, 211, 238, 0.94)');
        grad.addColorStop(1, 'rgba(125, 211, 252, 0.96)');
        ctx.strokeStyle = grad;
        ctx.shadowColor = 'rgba(34, 211, 238, 0.35)';
        ctx.shadowBlur = 6;
        ctx.lineWidth = Math.min(2.8, 1.25 + Math.log10(totalRate + 10) * 0.36);
      } else {
        ctx.strokeStyle = 'rgba(148, 163, 184, 0.28)';
        ctx.lineWidth = 0.95;
      }
      ctx.stroke();
      ctx.restore();

      // Animated comet particles on active non-blocked arcs
      if (isActive && !isAllBlocked && dist > 8) {
        const particleCount = totalRate > 50000 ? 3 : (totalRate > 2048 ? 2 : 1);
        for (let pIdx = 0; pIdx < particleCount; pIdx++) {
          const t = (animPhase + pIdx / particleCount) % 1;
          const pt = quadBezierPoint(originPt, ctrlPt, destPt, t);
          const tailPt = quadBezierPoint(originPt, ctrlPt, destPt, Math.max(0, t - 0.045));
          ctx.save();
          const tailGrad = ctx.createLinearGradient(tailPt.x, tailPt.y, pt.x, pt.y);
          tailGrad.addColorStop(0, 'rgba(34, 211, 238, 0)');
          tailGrad.addColorStop(1, 'rgba(165, 243, 252, 0.95)');
          ctx.strokeStyle = tailGrad;
          ctx.lineWidth = totalRate > 20000 ? 2.6 : 2.0;
          ctx.lineCap = 'round';
          ctx.beginPath();
          ctx.moveTo(tailPt.x, tailPt.y);
          ctx.lineTo(pt.x, pt.y);
          ctx.stroke();

          ctx.beginPath();
          ctx.arc(pt.x, pt.y, totalRate > 20000 ? 2.6 : 2.0, 0, Math.PI * 2);
          ctx.fillStyle = '#ecfeff';
          ctx.shadowColor = '#22d3ee';
          ctx.shadowBlur = 8;
          ctx.fill();
          ctx.restore();
        }
      }

      const radius = Math.min(7.2, 3.0 + Math.sqrt(hub.connCount) * 0.95);
      renderedMapHubs.push({
        ...hub,
        x: destPt.x,
        y: destPt.y,
        r: radius,
        isAllBlocked,
        isActive
      });
    }

    // 4. Destination Hub Nodes & Crisp Callout Pill Labels
    const labelBoxes = [];
    labelBoxes.push({ x1: originPt.x - 62, y1: originPt.y + 4, x2: originPt.x + 82, y2: originPt.y + 26 });

    renderedMapHubs.forEach((h, idx) => {
      const isSelected = mapHubFilter && mapHubFilter.key === h.key;
      const isHovered = hoveredHub && hoveredHub.key === h.key;
      const mainColor = h.isAllBlocked ? '#ef4444' : (h.isActive ? '#38bdf8' : '#94a3b8');

      if (h.isActive || isSelected || isHovered) {
        ctx.beginPath();
        ctx.arc(h.x, h.y, h.r + (isSelected ? 6.5 : 4.2), 0, Math.PI * 2);
        ctx.fillStyle = h.isAllBlocked ? 'rgba(239, 68, 68, 0.24)' : 'rgba(56, 189, 248, 0.20)';
        ctx.fill();

        ctx.beginPath();
        ctx.arc(h.x, h.y, h.r + (isSelected ? 8.5 : 6), 0, Math.PI * 2);
        ctx.strokeStyle = h.isAllBlocked ? 'rgba(248, 113, 113, 0.45)' : 'rgba(56, 189, 248, 0.38)';
        ctx.lineWidth = 0.85;
        ctx.stroke();
      }

      ctx.beginPath();
      ctx.arc(h.x, h.y, h.r, 0, Math.PI * 2);
      ctx.fillStyle = mainColor;
      ctx.fill();
      ctx.lineWidth = isSelected ? 1.8 : 1.1;
      ctx.strokeStyle = isSelected ? '#ffffff' : '#050912';
      ctx.stroke();

      // Inner bright core
      if (h.isActive && !h.isAllBlocked) {
        ctx.beginPath();
        ctx.arc(h.x, h.y, Math.max(1.2, h.r * 0.42), 0, Math.PI * 2);
        ctx.fillStyle = '#e0f2fe';
        ctx.fill();
      }

      // Label top 9 hubs without collisions
      if (idx < 10 || isSelected) {
        const locName = h.city || h.countryCode || '远端节点';
        const firstDom = Array.from(h.domains)[0] || '';
        const shortDom = firstDom.split(' ')[0].slice(0, 19);
        const label = shortDom ? `${locName} · ${shortDom}` : `${locName} (${h.connCount})`;

        ctx.font = '600 10.5px -apple-system, BlinkMacSystemFont, "SF Pro Text", "PingFang SC", sans-serif';
        const tw = ctx.measureText(label).width;
        let lx = h.x + h.r + 7;
        let ly = h.y + 3.5;
        if (lx + tw + 10 > cw) lx = h.x - h.r - tw - 8;

        const box = { x1: lx - 5, y1: ly - 11.5, x2: lx + tw + 5, y2: ly + 4.5 };
        const overlaps = !isSelected && labelBoxes.some(b =>
          !(box.x2 < b.x1 || box.x1 > b.x2 || box.y2 < b.y1 || box.y1 > b.y2)
        );

        if (!overlaps) {
          labelBoxes.push(box);
          ctx.save();
          ctx.fillStyle = 'rgba(6, 11, 21, 0.86)';
          ctx.strokeStyle = h.isAllBlocked
            ? 'rgba(239, 68, 68, 0.42)'
            : (h.isActive ? 'rgba(56, 189, 248, 0.36)' : 'rgba(71, 85, 105, 0.42)');
          ctx.lineWidth = 0.8;
          ctx.beginPath();
          if (typeof ctx.roundRect === 'function') {
            ctx.roundRect(box.x1, box.y1, box.x2 - box.x1, box.y2 - box.y1, 4);
          } else {
            ctx.rect(box.x1, box.y1, box.x2 - box.x1, box.y2 - box.y1);
          }
          ctx.fill();
          ctx.stroke();
          ctx.fillStyle = h.isAllBlocked ? '#fca5a5' : (h.isActive ? '#f0f9ff' : '#cbd5e1');
          ctx.fillText(label, lx, ly);
          ctx.restore();
        }
      }
    });

    // 5. Local Origin Beacon (Pulsing Radar)
    const pulseR = 6 + (animPhase * 14);
    ctx.beginPath();
    ctx.arc(originPt.x, originPt.y, pulseR, 0, Math.PI * 2);
    ctx.strokeStyle = `rgba(16, 185, 129, ${(1 - animPhase) * 0.75})`;
    ctx.lineWidth = 1.8;
    ctx.stroke();

    ctx.beginPath();
    ctx.arc(originPt.x, originPt.y, 5, 0, Math.PI * 2);
    ctx.fillStyle = '#10b981';
    ctx.fill();
    ctx.lineWidth = 2;
    ctx.strokeStyle = '#ffffff';
    ctx.stroke();

    ctx.font = '700 11.5px -apple-system, BlinkMacSystemFont, "PingFang SC", sans-serif';
    const originLabel = `本机 · ${radar.originCity || 'Local'}`;
    const ow = ctx.measureText(originLabel).width;
    ctx.fillStyle = 'rgba(6, 24, 20, 0.88)';
    ctx.fillRect(originPt.x - ow / 2 - 5, originPt.y + 8, ow + 10, 16);
    ctx.fillStyle = '#6ee7b7';
    ctx.fillText(originLabel, originPt.x - ow / 2, originPt.y + 20);

    ctx.restore();
  }

  function ensureMapAnimationLoop() {
    if (animFrameId) return;
    const prefersReduced = window.matchMedia?.('(prefers-reduced-motion: reduce)')?.matches;
    if (prefersReduced) return;

    let lastTs = 0;
    const tick = ts => {
      if (mainTab !== 'network' || paused) {
        animFrameId = null;
        return;
      }
      if (ts - lastTs >= 36) {
        lastTs = ts;
        animPhase = (animPhase + 0.016) % 1;
        if (latest) drawWorldMap(latest);
      }
      animFrameId = requestAnimationFrame(tick);
    };
    animFrameId = requestAnimationFrame(tick);
  }

  function renderFirewallDeck(snap) {
    if (!snap || !snap.netRadar || mainTab !== 'network') return;
    const radar = snap.netRadar;

    document.getElementById('mapOriginPill').textContent =
      `本机起点: ${radar.originCity || 'Local'}, ${radar.originCountry || ''}`;
    document.getElementById('netAppCountVal').textContent = `${radar.activeAppCount} 款`;
    document.getElementById('netConnCountVal').textContent = `${radar.publicConnCount} / ${radar.lanConnCount}`;
    document.getElementById('netTabRxVal').textContent = fmtRate(snap.network.rxBytesPerSec);
    document.getElementById('netTabTxVal').textContent = fmtRate(snap.network.txBytesPerSec);

    const rules = radar.blockedRules || [];
    document.getElementById('fwRuleCountBadge').textContent = `${rules.length} 条封禁`;
    document.getElementById('btnClearAllBlocks').classList.toggle('hidden', rules.length === 0);
    document.getElementById('btnClearMapFilter').classList.toggle('hidden', !mapHubFilter);

    const blockedConns = (radar.connections || []).filter(c => c.isBlocked).length;
    document.getElementById('blockedConnPill').textContent = String(Math.max(rules.length, blockedConns));

    const rulesBox = document.getElementById('fwRulesList');
    if (rules.length === 0) {
      rulesBox.innerHTML = `<div class="fw-empty-note">当前无受限网址或 IP，所有软件均可正常外联。点击下方表格「禁访问」可立即阻断。</div>`;
    } else {
      rulesBox.innerHTML = rules.map(r => `
        <div class="fw-rule-item">
          <div class="fw-rule-target">
            <span class="fw-rule-main mono">${escapeHtml(r.target)}</span>
            <span class="fw-rule-sub">${r.ruleType === 'domain' ? '域名拦截' : 'IP 阻断'}${r.resolvedIp ? ' · ' + escapeHtml(r.resolvedIp) : ''}${r.note ? ' · ' + escapeHtml(r.note) : ''}</span>
          </div>
          <button type="button" class="row-btn unblock" data-fw-unblock="${escapeHtml(r.id)}">恢复访问</button>
        </div>
      `).join('');
    }

    // Region distribution Top 5
    const countryMap = new Map();
    for (const c of (radar.connections || [])) {
      const label = c.country ? `${c.countryCode} · ${c.country}` : (c.countryCode || '未知地区');
      countryMap.set(label, (countryMap.get(label) || 0) + 1);
    }
    const topRegions = Array.from(countryMap.entries())
      .sort((a, b) => b[1] - a[1])
      .slice(0, 4);
    const maxCnt = Math.max(1, topRegions[0]?.[1] || 1);

    const regBox = document.getElementById('fwRegionsList');
    if (topRegions.length === 0) {
      regBox.innerHTML = `<span class="muted-note">暂无活跃公网远端节点</span>`;
    } else {
      regBox.innerHTML = topRegions.map(([name, cnt]) => `
        <div class="region-row">
          <span class="region-name" title="${escapeHtml(name)}">${escapeHtml(name)}</span>
          <div class="region-bar-track">
            <div class="region-bar-fill" style="width:${Math.max(6, (cnt / maxCnt) * 100).toFixed(1)}%"></div>
          </div>
          <span class="region-count mono">${cnt} 连接</span>
        </div>
      `).join('');
    }
  }

  function chooseBestBlockTarget(domain, remoteIp) {
    const d = String(domain || '').trim();
    // If domain is synthetic/umbrella (e.g. "google.com (1e100.net)" or "cloudflare-edge.net"), block exact IP so other sites stay safe
    if (!d || d === remoteIp || d.includes('(') || d.includes(' ') || d === 'cloudflare-edge.net' || d === 'amazonaws.com' || d === 'fastly.net' || d === 'akamai.com') {
      return remoteIp;
    }
    return d;
  }

  function renderNetTable(snap) {
    if (!snap || !snap.netRadar || mainTab !== 'network') return;
    const radar = snap.netRadar;
    const thead = document.getElementById('netTableHead');
    const tbody = document.getElementById('netTableBody');
    const q = netSearchQuery.trim().toLowerCase();

    if (netViewMode === 'apps') {
      thead.innerHTML = `
        <tr>
          <th>联网软件 / 进程</th>
          <th>安全护栏</th>
          <th>正在访问的网址域名与地区</th>
          <th>连接数</th>
          <th>↓ 实时下行 / ↑ 上行</th>
          <th>累计收发流量</th>
          <th class="col-actions">管控操作 (禁访问 / 杀掉)</th>
        </tr>
      `;

      const blockedIpSet = new Set((radar.connections || []).filter(c => c.isBlocked).map(c => c.remoteIp));
      const list = (radar.apps || []).filter(app => {
        const rate = (app.rxBps || 0) + (app.txBps || 0);
        const hasBlocked = (app.remoteIps || []).some(ip => blockedIpSet.has(ip));
        if (mapHubFilter && !(app.remoteIps || []).some(ip => mapHubFilter.ips.has(ip))) return false;
        if (netFilter === 'active' && rate < 1) return false;
        if (netFilter === 'heavy' && rate < 10240) return false;
        if (netFilter === 'blocked' && !hasBlocked) return false;
        if (q) {
          const hay = `${app.appName} ${app.processName} ${app.pid} ${(app.remoteDomains || []).join(' ')} ${(app.remoteIps || []).join(' ')} ${(app.countries || []).join(' ')}`.toLowerCase();
          if (!hay.includes(q)) return false;
        }
        return true;
      });

      if (list.length === 0) {
        tbody.innerHTML = `<tr><td colspan="7" class="empty-cell">当前筛选条件下没有匹配的联网软件</td></tr>`;
        return;
      }

      tbody.innerHTML = list.map(app => {
        const canKill = app.safetyTier !== 'system';
        const domains = (app.remoteDomains || []).slice(0, 4);
        const extraDomCount = Math.max(0, (app.remoteDomains || []).length - domains.length);
        const countries = (app.countries || []).slice(0, 4);
        const firstIp = (app.remoteIps || [])[0] || '';
        const firstDom = (app.remoteDomains || [])[0] || '';
        const blockTarget = chooseBestBlockTarget(firstDom, firstIp);
        const isPrimaryBlocked = firstIp && blockedIpSet.has(firstIp);

        return `
          <tr>
            <td>
              <div class="proc-main-cell">
                <div class="proc-title-line">
                  <span class="proc-name">${escapeHtml(app.appName)}</span>
                  ${app.processName !== app.appName ? `<span class="cat-badge mono">${escapeHtml(app.processName)}</span>` : ''}
                  ${countries.map(cc => `<span class="country-chip">${escapeHtml(cc)}</span>`).join('')}
                </div>
                <span class="proc-subline mono">PID ${app.pid} · 外联 IP: ${escapeHtml((app.remoteIps || []).slice(0, 2).join(', ') || '本地套接字')}</span>
              </div>
            </td>
            <td>${renderTierBadge(app.safetyTier, false)}</td>
            <td>
              <div class="domain-chips-wrap">
                ${domains.length > 0
                  ? domains.map(d => `<span class="domain-chip" title="${escapeHtml(d)}">${escapeHtml(d)}</span>`).join('')
                  : `<span class="muted-note">待机套接字 (无活跃外网域名)</span>`}
                ${extraDomCount > 0 ? `<span class="cat-badge mono">+${extraDomCount}</span>` : ''}
              </div>
            </td>
            <td class="mono">${app.connectionCount} 个连接</td>
            <td class="mono">
              <div class="${app.rxBps > 1024 ? 'text-cyan' : 'text-secondary'}">↓ <b>${fmtRate(app.rxBps)}</b></div>
              <div class="${app.txBps > 1024 ? 'text-blue' : 'text-muted'}" style="font-size:11.5px;">↑ ${fmtRate(app.txBps)}</div>
            </td>
            <td class="mono text-secondary">
              <div>↓ ${fmtBytes(app.totalRxBytes, 1)}</div>
              <div style="font-size:11px;">↑ ${fmtBytes(app.totalTxBytes, 1)}</div>
            </td>
            <td class="col-actions">
              <div class="row-actions">
                ${blockTarget ? (
                  isPrimaryBlocked
                    ? `<button type="button" class="row-btn unblock" data-net-act="unblock" data-target="${escapeHtml(blockTarget)}">恢复访问</button>`
                    : `<button type="button" class="row-btn block" data-net-act="block" data-target="${escapeHtml(blockTarget)}" data-ip="${escapeHtml(firstIp)}" data-note="${escapeHtml(app.appName)}" title="阻断 ${escapeHtml(blockTarget)}">禁访问</button>`
                ) : ''}
                ${canKill
                  ? `<button type="button" class="row-btn kill" data-net-act="kill-pid" data-pid="${app.pid}" data-name="${escapeHtml(app.appName)}">杀掉软件</button>`
                  : `<span class="lock-tag">系统保护</span>`}
              </div>
            </td>
          </tr>
        `;
      }).join('');
    } else {
      thead.innerHTML = `
        <tr>
          <th>所属软件 / PID</th>
          <th>访问网址域名 / 归属机构</th>
          <th>远端 IP : 端口 / 协议</th>
          <th>国家与城市坐标</th>
          <th>↓ 实时下行 / ↑ 上行</th>
          <th>累计流量</th>
          <th class="col-actions">管控操作 (禁访问 / 杀掉)</th>
        </tr>
      `;

      const list = (radar.connections || []).filter(c => {
        const rate = (c.rxBps || 0) + (c.txBps || 0);
        if (mapHubFilter && !mapHubFilter.ips.has(c.remoteIp)) return false;
        if (netFilter === 'active' && rate < 1) return false;
        if (netFilter === 'heavy' && rate < 10240) return false;
        if (netFilter === 'blocked' && !c.isBlocked) return false;
        if (q) {
          const hay = `${c.appName} ${c.processName} ${c.pid} ${c.domain} ${c.org} ${c.remoteIp} ${c.country} ${c.countryCode} ${c.city}`.toLowerCase();
          if (!hay.includes(q)) return false;
        }
        return true;
      });

      if (list.length === 0) {
        tbody.innerHTML = `<tr><td colspan="7" class="empty-cell">当前筛选条件下没有匹配的远端连接</td></tr>`;
        return;
      }

      tbody.innerHTML = list.map(c => {
        const canKill = c.safetyTier !== 'system';
        const blockTarget = chooseBestBlockTarget(c.domain, c.remoteIp);
        const locStr = [c.countryCode, c.city || c.country].filter(Boolean).join(' · ') || '公网节点';

        return `
          <tr>
            <td>
              <div class="proc-main-cell">
                <div class="proc-title-line">
                  <span class="proc-name">${escapeHtml(c.appName)}</span>
                  <span class="mono text-muted" style="font-size:11.5px;">[${c.pid}]</span>
                </div>
                <span class="proc-subline mono">${escapeHtml(c.processName)}</span>
              </div>
            </td>
            <td>
              <div class="proc-main-cell">
                <div class="proc-title-line">
                  <span class="domain-chip ${c.isBlocked ? 'blocked' : ''}" title="${escapeHtml(c.domain)}">${escapeHtml(c.domain)}</span>
                </div>
                <span class="proc-subline">${escapeHtml(c.org || '--')}</span>
              </div>
            </td>
            <td class="mono">
              <span class="proto-chip ${c.proto === 'QUIC' ? 'quic' : ''}">${escapeHtml(c.proto)}</span>
              <span style="margin-left:4px;">${escapeHtml(c.remoteIp)}:${c.remotePort}</span>
            </td>
            <td>
              <span class="country-chip">${escapeHtml(locStr)}</span>
            </td>
            <td class="mono">
              <div class="${c.rxBps > 1024 ? 'text-cyan' : 'text-secondary'}">↓ <b>${fmtRate(c.rxBps)}</b></div>
              <div class="${c.txBps > 1024 ? 'text-blue' : 'text-muted'}" style="font-size:11.5px;">↑ ${fmtRate(c.txBps)}</div>
            </td>
            <td class="mono text-secondary">
              <div>↓ ${fmtBytes(c.totalRxBytes, 1)}</div>
              <div style="font-size:11px;">↑ ${fmtBytes(c.totalTxBytes, 1)}</div>
            </td>
            <td class="col-actions">
              <div class="row-actions">
                ${c.isBlocked
                  ? `<button type="button" class="row-btn unblock" data-net-act="unblock" data-target="${escapeHtml(c.remoteIp)}" data-domain="${escapeHtml(blockTarget)}">恢复访问</button>`
                  : `<button type="button" class="row-btn block" data-net-act="block" data-target="${escapeHtml(blockTarget)}" data-ip="${escapeHtml(c.remoteIp)}" data-note="${escapeHtml(c.appName)}">禁访问</button>`}
                ${canKill
                  ? `<button type="button" class="row-btn kill" data-net-act="kill-pid" data-pid="${c.pid}" data-name="${escapeHtml(c.appName)}">杀掉软件</button>`
                  : `<span class="lock-tag">系统保护</span>`}
              </div>
            </td>
          </tr>
        `;
      }).join('');
    }
  }

  // ==================== ACTIONS: KILL & FIREWALL ====================
  async function executeKillRequest(pids, force, labelSummary) {
    if (!pids || pids.length === 0) return;
    try {
      const res = await apiPost('/api/kill', {
        pids,
        force,
        ensureDead: force
      });
      if (res.snapshot) {
        latest = res.snapshot;
        renderAll(latest);
      }
      const freedActual = Math.max(res.systemFreedBytes || 0, res.estimatedFreedBytes || 0);
      if (res.killedCount > 0) {
        showToast(
          `<div><b>已终止进程并回收资源 (${res.signal})</b></div>` +
          `<div style="margin-top:3px;color:#cbd5e1;">已关闭 <b>${res.killedCount}</b> 个进程 (${escapeHtml(labelSummary)})，释放约 <b class="text-emerald mono">${fmtBytes(freedActual, 2)}</b></div>`
        );
      }
      if (res.blocked && res.blocked.length > 0) {
        showToast(`已跳过 ${res.blocked.length} 个受保护系统进程`, 'warn');
      }
      if (res.failed && res.failed.length > 0) {
        showToast(`部分进程未能终止: ${escapeHtml(res.failed.map(f => `${f.name}(${f.error})`).join(', '))}`, 'error');
      }
    } catch (err) {
      showToast(`操作失败：${escapeHtml(err.message)}`, 'error');
    }
  }

  async function executeFirewallBlock(target, relatedIp, note) {
    if (!target) return;
    try {
      showToast(`正在请求系统防火墙阻断 <b class="mono">${escapeHtml(target)}</b>（请在系统弹窗中确认授权）…`, 'warn', 3200);
      const res = await apiPost('/api/firewall/block', { target, relatedIp: relatedIp || '', note: note || '' });
      if (res.snapshot) {
        latest = res.snapshot;
        renderAll(latest);
      }
      showToast(`已成功禁访问：<b class="mono">${escapeHtml(target)}</b>（Hosts + PF 内核阻断已生效）`);
    } catch (err) {
      showToast(`禁访问未生效：${escapeHtml(err.message)}`, 'error');
    }
  }

  async function executeFirewallUnblock(targetOrId, fallbackDomain) {
    try {
      let res = await apiPost('/api/firewall/unblock', { target: targetOrId });
      if (fallbackDomain && fallbackDomain !== targetOrId) {
        res = await apiPost('/api/firewall/unblock', { target: fallbackDomain });
      }
      if (res.snapshot) {
        latest = res.snapshot;
        renderAll(latest);
      }
      showToast(`已恢复网络访问：<b class="mono">${escapeHtml(fallbackDomain || targetOrId)}</b>`);
    } catch (err) {
      showToast(`恢复访问失败：${escapeHtml(err.message)}`, 'error');
    }
  }

  function openConfirmModal({ title, desc, targetsList, pids, summaryLabel, defaultForce }) {
    const modal = document.getElementById('confirmModal');
    document.getElementById('modalTitle').textContent = title;
    document.getElementById('modalDesc').textContent = desc;
    document.getElementById('modalTargets').innerHTML = targetsList
      .slice(0, 20)
      .map(t => `<div>• ${escapeHtml(t)}</div>`)
      .join('') + (targetsList.length > 20 ? `<div>…及其他 ${targetsList.length - 20} 项</div>` : '');

    pendingModalAction = { pids, summaryLabel };
    modal.classList.remove('hidden');

    const focusBtn = defaultForce ? document.getElementById('modalKillBtn') : document.getElementById('modalTermBtn');
    if (focusBtn) focusBtn.focus();
  }

  function closeConfirmModal() {
    document.getElementById('confirmModal').classList.add('hidden');
    pendingModalAction = null;
  }

  function requestKillGroup(groupKey, force) {
    if (!latest) return;
    const g = (latest.appGroups || []).find(item => item.groupKey === groupKey);
    if (!g || g.safetyTier === 'system') return;

    const needsConfirm = g.safetyTier === 'session' || g.processCount > 2 || g.totalFootprintBytes > 1.5 * 1073741824 || force;
    if (!needsConfirm) {
      executeKillRequest(g.pids, force, g.appName);
      return;
    }

    const warnPrefix = g.safetyTier === 'session'
      ? '注意：该目标属于当前活跃工作台、AI 线程或训练任务，强杀可能中断正在进行的工作！'
      : `即将终止「${g.appName}」及其关联的 ${g.processCount} 个进程，预计回收 ${fmtBytes(g.totalFootprintBytes, 2)} 内存。`;

    openConfirmModal({
      title: force ? `强制杀掉「${g.appName}」并回收内存` : `结束「${g.appName}」释放内存`,
      desc: warnPrefix,
      targetsList: [`${g.appName} (共 ${g.processCount} 个进程，合计 ${fmtBytes(g.totalFootprintBytes, 2)})`],
      pids: g.pids,
      summaryLabel: g.appName,
      defaultForce: force
    });
  }

  function requestKillSinglePid(pid, force, fallbackName = '') {
    if (!latest) return;
    const p = (latest.topProcesses || []).find(item => item.pid === pid);
    if (!p) {
      if (pid <= 1) return;
      openConfirmModal({
        title: `杀掉联网软件 ${fallbackName || 'PID ' + pid}`,
        desc: `确认终止进程 PID ${pid} (${fallbackName || '联网进程'}) 并立即切断其网络连接吗？`,
        targetsList: [`[PID ${pid}] ${fallbackName || '进程'}`],
        pids: [pid],
        summaryLabel: fallbackName || `PID ${pid}`,
        defaultForce: force
      });
      return;
    }
    if (p.safetyTier === 'system') return;

    if (p.safetyTier !== 'session' && p.footprintBytes < 1.5 * 1073741824 && !force) {
      executeKillRequest([p.pid], false, `${p.name} (${p.pid})`);
      return;
    }

    openConfirmModal({
      title: `终止进程 ${p.appName || p.name} (PID ${p.pid})`,
      desc: p.safetyTier === 'session'
        ? '注意：该进程属于当前工作台、训练任务或 AI 会话，确认要终止吗？'
        : `该进程当前占用 ${fmtBytes(p.footprintBytes, 2)} 内存，终止后将同步断开其全部网络连接：`,
      targetsList: [`[PID ${p.pid}] ${p.name} ${p.projectHint ? '(' + p.projectHint + ')' : ''} — ${fmtBytes(p.footprintBytes, 2)}`],
      pids: [p.pid],
      summaryLabel: `${p.appName || p.name} (${p.pid})`,
      defaultForce: force
    });
  }

  function switchMainTab(nextTab) {
    mainTab = nextTab === 'network' ? 'network' : 'hardware';
    document.querySelectorAll('[data-main-tab]').forEach(btn => {
      const active = btn.getAttribute('data-main-tab') === mainTab;
      btn.classList.toggle('active', active);
      btn.setAttribute('aria-selected', active ? 'true' : 'false');
    });

    document.getElementById('tabHardware').classList.toggle('hidden', mainTab !== 'hardware');
    document.getElementById('tabNetwork').classList.toggle('hidden', mainTab !== 'network');
    document.querySelectorAll('.hw-only-action').forEach(el => {
      el.classList.toggle('hidden', mainTab !== 'hardware');
    });

    if (latest) {
      renderAll(latest);
    }
    if (mainTab === 'network') {
      ensureMapAnimationLoop();
    }
  }

  function renderAll(snap) {
    if (!snap) return;
    renderTopTelemetry(snap);
    if (mainTab === 'hardware') {
      renderTreemap(snap);
      renderTable(snap);
    } else {
      drawWorldMap(snap);
      renderFirewallDeck(snap);
      renderNetTable(snap);
    }
  }

  // ==================== EVENT BINDINGS ====================
  function bindEvents() {
    // Main Tab Switcher
    document.querySelectorAll('[data-main-tab]').forEach(btn => {
      btn.addEventListener('click', () => {
        switchMainTab(btn.getAttribute('data-main-tab'));
      });
    });

    // Tab 1 Table events
    const tbody = document.getElementById('procTableBody');
    tbody.addEventListener('change', e => {
      const chk = e.target.closest('.row-check');
      if (!chk) return;
      const key = chk.getAttribute('data-sel-key');
      if (!key) return;
      if (chk.checked) selectedKeys.add(key);
      else selectedKeys.delete(key);
      renderTable(latest);
    });

    tbody.addEventListener('click', e => {
      const expandBtn = e.target.closest('[data-expand-group]');
      if (expandBtn) {
        const gKey = expandBtn.getAttribute('data-expand-group');
        if (expandedGroups.has(gKey)) expandedGroups.delete(gKey);
        else expandedGroups.add(gKey);
        renderTable(latest);
        return;
      }

      const actBtn = e.target.closest('[data-act]');
      if (!actBtn) return;
      const act = actBtn.getAttribute('data-act');
      if (act === 'term-group') requestKillGroup(actBtn.getAttribute('data-key'), false);
      else if (act === 'kill-group') requestKillGroup(actBtn.getAttribute('data-key'), true);
      else if (act === 'term-pid') requestKillSinglePid(Number(actBtn.getAttribute('data-pid')), false);
      else if (act === 'kill-pid') requestKillSinglePid(Number(actBtn.getAttribute('data-pid')), true);
    });

    // Tab 2 World Map Hover & Click-to-Filter
    const mapCanvas = document.getElementById('worldMapCanvas');
    const tooltip = document.getElementById('mapTooltip');
    mapCanvas.addEventListener('mousemove', e => {
      const rect = mapCanvas.getBoundingClientRect();
      const mx = e.clientX - rect.left;
      const my = e.clientY - rect.top;
      let hit = null;
      for (const h of renderedMapHubs) {
        if (Math.hypot(mx - h.x, my - h.y) <= Math.max(10, h.r + 5)) {
          hit = h;
          break;
        }
      }
      hoveredHub = hit;
      if (!hit) {
        tooltip.classList.add('hidden');
        return;
      }
      const appsStr = Array.from(hit.apps).slice(0, 4).join(', ');
      const domsStr = Array.from(hit.domains).slice(0, 3).join(', ');
      tooltip.innerHTML = `
        <div><b>${escapeHtml(hit.city || '远端节点')} ${escapeHtml(hit.countryCode ? '(' + hit.countryCode + ')' : '')}</b> · ${hit.connCount} 个连接</div>
        <div class="mono text-cyan" style="margin-top:2px;">↓ ${fmtRate(hit.rxBps)} / ↑ ${fmtRate(hit.txBps)}</div>
        <div style="margin-top:3px;color:#cbd5e1;">软件: ${escapeHtml(appsStr || '--')}</div>
        <div class="mono" style="color:#94a3b8;font-size:10.5px;">网址: ${escapeHtml(domsStr || Array.from(hit.ips)[0] || '--')}</div>
        <div style="margin-top:3px;color:#6ee7b7;font-size:10.5px;">点击节点可在下方表格筛选该地区连接</div>
      `;
      tooltip.classList.remove('hidden');
      const tx = Math.min(rect.width - 260, Math.max(8, mx + 14));
      const ty = Math.min(rect.height - 105, Math.max(8, my - 18));
      tooltip.style.left = `${tx}px`;
      tooltip.style.top = `${ty}px`;
    });

    mapCanvas.addEventListener('mouseleave', () => {
      hoveredHub = null;
      tooltip.classList.add('hidden');
    });

    mapCanvas.addEventListener('click', () => {
      if (!hoveredHub) {
        if (mapHubFilter) {
          mapHubFilter = null;
          renderAll(latest);
        }
        return;
      }
      if (mapHubFilter && mapHubFilter.key === hoveredHub.key) {
        mapHubFilter = null;
      } else {
        mapHubFilter = { key: hoveredHub.key, ips: new Set(hoveredHub.ips) };
      }
      renderAll(latest);
    });

    document.getElementById('btnClearMapFilter').addEventListener('click', () => {
      mapHubFilter = null;
      renderAll(latest);
    });

    // Tab 2 Firewall Form & Rules
    document.getElementById('fwBlockForm').addEventListener('submit', e => {
      e.preventDefault();
      const input = document.getElementById('fwTargetInput');
      const raw = (input.value || '').trim();
      if (!raw) return;
      input.value = '';
      executeFirewallBlock(raw, '', '手动添加');
    });

    document.getElementById('fwRulesList').addEventListener('click', e => {
      const btn = e.target.closest('[data-fw-unblock]');
      if (!btn) return;
      executeFirewallUnblock(btn.getAttribute('data-fw-unblock'));
    });

    document.getElementById('btnClearAllBlocks').addEventListener('click', async () => {
      try {
        const res = await apiPost('/api/firewall/clear', {});
        if (res.snapshot) {
          latest = res.snapshot;
          renderAll(latest);
        }
        showToast('已清空全部网络访问限制，所有域名与 IP 已恢复连接');
      } catch (err) {
        showToast(`操作失败：${escapeHtml(err.message)}`, 'error');
      }
    });

    // Tab 2 View Mode, Filters, Search & Row Actions
    document.querySelectorAll('[data-net-view]').forEach(btn => {
      btn.addEventListener('click', () => {
        netViewMode = btn.getAttribute('data-net-view') || 'apps';
        document.querySelectorAll('[data-net-view]').forEach(b => b.classList.toggle('active', b === btn));
        renderNetTable(latest);
      });
    });

    document.querySelectorAll('[data-net-filter]').forEach(btn => {
      btn.addEventListener('click', () => {
        netFilter = btn.getAttribute('data-net-filter') || 'all';
        document.querySelectorAll('[data-net-filter]').forEach(b => b.classList.toggle('active', b === btn));
        renderNetTable(latest);
      });
    });

    document.getElementById('netSearchInput').addEventListener('input', e => {
      netSearchQuery = e.target.value || '';
      renderNetTable(latest);
    });

    document.getElementById('netTableBody').addEventListener('click', e => {
      const btn = e.target.closest('[data-net-act]');
      if (!btn) return;
      const act = btn.getAttribute('data-net-act');
      if (act === 'block') {
        executeFirewallBlock(
          btn.getAttribute('data-target'),
          btn.getAttribute('data-ip'),
          btn.getAttribute('data-note')
        );
      } else if (act === 'unblock') {
        executeFirewallUnblock(
          btn.getAttribute('data-target'),
          btn.getAttribute('data-domain')
        );
      } else if (act === 'kill-pid') {
        requestKillSinglePid(
          Number(btn.getAttribute('data-pid')),
          true,
          btn.getAttribute('data-name') || ''
        );
      }
    });

    // Shared Topbar & Tab 1 Controls
    document.getElementById('checkAllSafe').addEventListener('change', e => {
      if (!latest) return;
      const checked = e.target.checked;
      const { mode, list } = getFilteredItems(latest);
      for (const item of list) {
        if (item.safetyTier !== 'safe') continue;
        const key = mode === 'groups' ? item.groupKey : `pid:${item.pid}`;
        if (checked) selectedKeys.add(key);
        else selectedKeys.delete(key);
      }
      renderTable(latest);
    });

    document.querySelectorAll('[data-interval]').forEach(btn => {
      btn.addEventListener('click', async () => {
        document.querySelectorAll('[data-interval]').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        const ms = Number(btn.getAttribute('data-interval')) || 1000;
        try {
          await apiPost('/api/interval', { intervalMs: ms });
        } catch (err) {
          showToast(escapeHtml(err.message), 'error');
        }
      });
    });

    document.getElementById('btnPause').addEventListener('click', () => {
      paused = !paused;
      document.getElementById('pauseLabel').textContent = paused ? '恢复' : '暂停';
      document.getElementById('liveDot').classList.toggle('paused', paused);
      if (!paused && mainTab === 'network') ensureMapAnimationLoop();
    });

    document.getElementById('btnSmartSelect').addEventListener('click', () => {
      if (!latest) return;
      if (mainTab !== 'hardware') switchMainTab('hardware');
      viewMode = 'groups';
      document.querySelectorAll('[data-view]').forEach(b => {
        b.classList.toggle('active', b.getAttribute('data-view') === 'groups');
      });

      const procByPid = new Map((latest.topProcesses || []).map(p => [p.pid, p]));
      selectedKeys.clear();
      let count = 0;
      for (const g of (latest.appGroups || [])) {
        if (isGroupReclaimable(g, procByPid)) {
          selectedKeys.add(g.groupKey);
          count++;
        }
      }
      renderTable(latest);

      if (count > 0) {
        const info = resolveSelectedTargets(latest);
        showToast(`已自动勾选 <b>${count}</b> 个低活跃高内存目标（预计可释放 <b class="text-emerald">${fmtBytes(info.estBytes, 2)}</b>），请核对下方列表后点击释放按钮。`, 'warn');
        document.getElementById('bulkBar').scrollIntoView({ behavior: 'smooth', block: 'nearest' });
      } else {
        showToast('当前未发现闲置超标的可疑大内存进程，所有高内存任务均处于活跃状态。');
      }
    });

    document.getElementById('btnPurgeCache').addEventListener('click', async () => {
      const btn = document.getElementById('btnPurgeCache');
      btn.disabled = true;
      const origHtml = btn.innerHTML;
      btn.textContent = '清理中…';
      try {
        const res = await apiPost('/api/purge', { adminPurge: true });
        if (res.snapshot) {
          latest = res.snapshot;
          renderAll(latest);
        }
        showToast(`内核文件缓存 Purge 完成！立即可用内存提升至 <b class="mono text-emerald">${fmtBytes(res.afterAvailableBytes, 2)}</b> (净增 ${fmtBytes(res.systemFreedBytes, 2)})`);
      } catch (err) {
        showToast(escapeHtml(err.message), 'warn');
      } finally {
        btn.disabled = false;
        btn.innerHTML = origHtml;
      }
    });

    document.getElementById('btnFullscreen').addEventListener('click', () => {
      if (!document.fullscreenElement) {
        document.documentElement.requestFullscreen?.().catch(() => {});
      } else {
        document.exitFullscreen?.().catch(() => {});
      }
    });

    document.querySelectorAll('[data-view]').forEach(btn => {
      btn.addEventListener('click', () => {
        viewMode = btn.getAttribute('data-view') || 'groups';
        selectedKeys.clear();
        document.getElementById('checkAllSafe').checked = false;
        document.querySelectorAll('[data-view]').forEach(b => b.classList.toggle('active', b === btn));
        renderTable(latest);
      });
    });

    document.querySelectorAll('[data-filter]').forEach(btn => {
      btn.addEventListener('click', () => {
        activeFilter = btn.getAttribute('data-filter') || 'all';
        document.querySelectorAll('[data-filter]').forEach(b => b.classList.toggle('active', b === btn));
        renderTable(latest);
      });
    });

    document.getElementById('btnClearGroupFilter').addEventListener('click', () => {
      treemapGroupKey = null;
      renderTreemap(latest);
      renderTable(latest);
    });

    document.getElementById('searchInput').addEventListener('input', e => {
      searchQuery = e.target.value || '';
      renderTable(latest);
    });

    document.querySelectorAll('th.sortable').forEach(th => {
      th.addEventListener('click', () => {
        const col = th.getAttribute('data-sort');
        if (sortBy === col) sortAsc = !sortAsc;
        else {
          sortBy = col;
          sortAsc = col === 'name';
        }
        document.querySelectorAll('th.sortable').forEach(h => h.classList.remove('active-sort'));
        th.classList.add('active-sort');
        renderTable(latest);
      });
    });

    document.getElementById('btnClearSelection').addEventListener('click', () => {
      selectedKeys.clear();
      document.getElementById('checkAllSafe').checked = false;
      renderTable(latest);
    });

    const triggerBulkModal = force => {
      const info = resolveSelectedTargets(latest);
      if (info.pids.length === 0) return;
      openConfirmModal({
        title: force ? `批量强制杀掉 ${info.pids.length} 个进程` : `批量优雅结束 ${info.pids.length} 个进程`,
        desc: info.hasSession
          ? '警告：您勾选的项目中包含当前活跃工作台或 AI 会话，终止它们可能导致当前窗口关闭！'
          : `预计可释放约 ${fmtBytes(info.estBytes, 2)} 物理内存，确认继续吗？`,
        targetsList: info.labels,
        pids: info.pids,
        summaryLabel: `${selectedKeys.size} 项批量清理`,
        defaultForce: force
      });
    };

    document.getElementById('btnBulkTerm').addEventListener('click', () => triggerBulkModal(false));
    document.getElementById('btnBulkKill').addEventListener('click', () => triggerBulkModal(true));

    document.getElementById('modalCancelBtn').addEventListener('click', closeConfirmModal);
    document.getElementById('confirmModal').addEventListener('click', e => {
      if (e.target.id === 'confirmModal') closeConfirmModal();
    });
    document.getElementById('modalTermBtn').addEventListener('click', () => {
      if (!pendingModalAction) return;
      const { pids, summaryLabel } = pendingModalAction;
      closeConfirmModal();
      selectedKeys.clear();
      executeKillRequest(pids, false, summaryLabel);
    });
    document.getElementById('modalKillBtn').addEventListener('click', () => {
      if (!pendingModalAction) return;
      const { pids, summaryLabel } = pendingModalAction;
      closeConfirmModal();
      selectedKeys.clear();
      executeKillRequest(pids, true, summaryLabel);
    });
    window.addEventListener('keydown', e => {
      if (e.key === 'Escape') closeConfirmModal();
    });

    window.addEventListener('resize', () => {
      if (latest) renderAll(latest);
    });
  }

  // ==================== TELEMETRY STREAMING ====================
  async function connectTelemetry() {
    const dot = document.getElementById('liveDot');

    // Native macOS Standalone Mode (WKWebView direct push)
    window.__onMacPulseFrame = snap => {
      dot.classList.remove('offline');
      if (paused) return;
      latest = snap;
      renderAll(snap);
    };

    if (window.__MACPULSE_NATIVE__ && window.webkit?.messageHandlers?.macpulseApi) {
      try {
        const snap = await apiPost('/api/snapshot', {});
        if (snap && snap.cpu) {
          latest = snap;
          renderAll(snap);
        }
      } catch {
        // streaming timer will push shortly
      }
      return;
    }

    // Web / Local Dev Server Mode — connect SSE immediately in parallel with initial snapshot fetch
    const q = hostPidParam ? `?hostPid=${encodeURIComponent(hostPidParam)}` : '';
    if (es) es.close();
    es = new EventSource(`/api/stream${q}`);
    es.onopen = () => dot.classList.remove('offline');
    es.onmessage = evt => {
      if (paused) return;
      try {
        const snap = JSON.parse(evt.data);
        latest = snap;
        renderAll(snap);
      } catch {
        // ignore parse error
      }
    };
    es.onerror = () => dot.classList.add('offline');

    fetch(`/api/snapshot${q}`)
      .then(res => (res.ok ? res.json() : null))
      .then(snap => {
        if (snap && !latest) {
          latest = snap;
          renderAll(snap);
        }
      })
      .catch(() => {});
  }

  // Allow URL hash/query ?tab=network for direct preview/testing
  if (params.get('tab') === 'network' || window.location.hash === '#network') {
    mainTab = 'network';
  }

  bindEvents();
  switchMainTab(mainTab);
  connectTelemetry();
})();
