#!/bin/bash
set -euo pipefail

CMD="${1:-status}"

case "$CMD" in
  status)
    line=$(/usr/bin/pmset -g 2>/dev/null | /usr/bin/grep -i "SleepDisabled" | /usr/bin/head -n 1 || true)
    val=$(printf '%s' "$line" | /usr/bin/awk '{print $2}')
    if [ "$val" = "1" ]; then
      printf '{"active":true,"title":"已开启 · 合盖保持运行","detail":"pmset SleepDisabled = 1（MacBook 合盖后不会自动休眠）"}\n'
    else
      printf '{"active":false,"title":"已关闭 · 正常休眠模式","detail":"pmset SleepDisabled = %s（合盖后将按系统默认策略休眠）"}\n' "${val:-0}"
    fi
    ;;
  enable)
    /usr/bin/pmset -a disablesleep 1
    /usr/bin/pmset -b sleep 0 disksleep 0
    echo "已开启合盖常运行（SleepDisabled = 1）"
    /usr/bin/pmset -g | /usr/bin/grep -i "SleepDisabled" || true
    ;;
  disable)
    /usr/bin/pmset -a disablesleep 0
    /usr/bin/pmset -b sleep 10 disksleep 10
    echo "已关闭合盖常运行，恢复默认休眠策略（SleepDisabled = 0）"
    /usr/bin/pmset -g | /usr/bin/grep -i "SleepDisabled" || true
    ;;
  *)
    echo "未知指令: $CMD" >&2
    exit 1
    ;;
esac
