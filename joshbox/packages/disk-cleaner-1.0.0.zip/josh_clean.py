#!/usr/bin/env python3
"""Offline, fail-closed cleanup. Python standard library only; never invokes an AI."""
import argparse
from contextlib import closing
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import stat
import sqlite3
import subprocess
import sys
import time

HOME = Path.home()
STATE = HOME / 'Library/Application Support/JoshLabs/disk-cleanup'
LOGS = HOME / 'Library/Logs/JoshLabs'
DEFAULT_REPO = HOME / 'Desktop/APP/07Cabinet-X'


def run(args, ok=(0,)):
    r = subprocess.run([str(x) for x in args], stdout=subprocess.PIPE,
                       stderr=subprocess.PIPE, timeout=90)
    if r.returncode not in ok:
        raise RuntimeError(f'{args[0]} 检查失败（退出 {r.returncode}），跳过')
    return r.stdout


def git(path, *args):
    return run(['git', '-C', path, *args])


def canonical(path):
    return Path(os.path.realpath(path))


def under(path, root):
    return path == root or root in path.parents


def atomic_json(path, data):
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    tmp = path.with_name(path.name + f'.{os.getpid()}.tmp')
    with open(tmp, 'x', encoding='utf-8') as f:
        os.chmod(tmp, 0o600)
        json.dump(data, f, ensure_ascii=False, indent=2)
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, path)


def probe_usage():
    # lsof exit 1 with no diagnostics means no matching open files. Any error fails closed.
    r = subprocess.run(['lsof', '-nP', '-w', '-u', str(os.getuid()), '-F', 'n'],
                       stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=90)
    if r.returncode not in (0, 1) or r.stderr.strip():
        raise RuntimeError('无法完整读取当前用户的打开文件；停止清理')
    names = []
    for line in r.stdout.decode(errors='replace').splitlines():
        if line.startswith('n/'):
            names.append(canonical(line[1:].removesuffix(' (deleted)')))
    commands = run(['ps', '-axo', 'args=']).decode(errors='replace')
    return names, commands


def assert_idle(path, usage):
    names, commands = usage
    if any(under(p, path) for p in names):
        raise RuntimeError('有进程打开文件或以此目录为工作目录')
    aliases = {str(path), str(path).replace('/private/tmp/', '/tmp/')}
    if any(s in commands for s in aliases):
        raise RuntimeError('运行中的命令引用此目录')


def tree_info(path, cutoff=None):
    """Constant-memory traversal; no symlink following; reject special files/mounts/recent writes."""
    device = path.lstat().st_dev
    total = 0
    newest = 0
    for dp, ds, fs in os.walk(path, followlinks=False, onerror=lambda e: (_ for _ in ()).throw(e)):
        for p in [Path(dp)] + [Path(dp) / n for n in ds + fs]:
            s = p.lstat()
            if s.st_dev != device:
                raise RuntimeError('内部有其它挂载点')
            if not (stat.S_ISREG(s.st_mode) or stat.S_ISDIR(s.st_mode) or stat.S_ISLNK(s.st_mode)):
                raise RuntimeError('内部有 socket 或特殊文件')
            newest = max(newest, s.st_mtime, s.st_ctime)
            if cutoff is not None and newest > cutoff:
                raise RuntimeError('目录近期有写入，尚未超过冷却期')
            if stat.S_ISREG(s.st_mode):
                total += s.st_blocks * 512
    return total


def snapshot(path):
    """Hash local state in bounded chunks, including empty directories and symlinks."""
    result = {}
    def add(p):
        rel = str(p.relative_to(path))
        if p.is_symlink():
            result[rel] = ['link', os.readlink(p)]
        elif p.is_dir():
            result[rel] = ['directory']
        elif p.is_file():
            h = hashlib.sha256()
            with p.open('rb') as f:
                for b in iter(lambda: f.read(1024 * 1024), b''):
                    h.update(b)
            result[rel] = ['file', p.stat().st_size, h.hexdigest()]
        else:
            raise RuntimeError('本地状态含特殊文件，保留原目录')
    add(path)
    if path.is_dir() and not path.is_symlink():
        for dp, ds, fs in os.walk(path, followlinks=False):
            for n in ds + fs:
                add(Path(dp) / n)
    return result


def worktree_metadata(repo, path):
    raw = git(repo, 'worktree', 'list', '--porcelain', '-z')
    for block in raw.split(b'\0\0'):
        fields = {}
        for item in block.split(b'\0'):
            k, _, v = os.fsdecode(item).partition(' ')
            fields[k] = v
        if fields.get('worktree') and canonical(fields['worktree']) == path:
            if 'locked' in fields or 'prunable' in fields:
                raise RuntimeError('worktree 已锁定或状态不完整')
            return fields
    raise RuntimeError('不是登记在指定仓库的 worktree')


def assert_no_active_chats(repo):
    """Read-only local state; any active chat in this Git family protects every worktree.

    Missing/changed schemas or unresolved active cwd fail closed. No transcript reads.
    """
    catalog = HOME / '.codex/sqlite/codex.db'
    state = HOME / '.codex/state_5.sqlite'
    try:
        with closing(sqlite3.connect(f'file:{catalog}?mode=ro', uri=True, timeout=2)) as db:
            active = [r[0] for r in db.execute('SELECT thread_id FROM active_chat_turns')]
        if not active:
            return
        common = canonical(repo / git(repo, 'rev-parse', '--git-common-dir').decode().strip())
        with closing(sqlite3.connect(f'file:{state}?mode=ro', uri=True, timeout=2)) as db:
            for thread in active:
                row = db.execute('SELECT cwd FROM threads WHERE id=?', (thread,)).fetchone()
                if not row or not row[0] or not Path(row[0]).is_dir():
                    raise RuntimeError('运行中聊天的目录无法确认，保留 worktree')
                cwd = canonical(row[0])
                # Non-Git chat directories may still contain the protected checkout.
                if under(repo, cwd) or under(cwd, repo):
                    raise RuntimeError('同仓库有运行中的聊天，保留全部 worktree')
                result = subprocess.run(['git', '-C', str(cwd), 'rev-parse', '--git-common-dir'],
                                        capture_output=True, timeout=10)
                if result.returncode != 0:
                    raise RuntimeError('活动聊天未绑定可确认的 Git 仓库，保留 worktree')
                if canonical(cwd / result.stdout.decode().strip()) == common:
                    raise RuntimeError('同仓库有运行中的聊天，保留全部 worktree')
    except sqlite3.Error as e:
        raise RuntimeError('无法读取运行中聊天状态，保留 worktree') from e


def promote_events():
    """A successful exact-HEAD build is only a candidate, never proof of idle ownership."""
    for event in (STATE / 'events').glob('*.json'):
        try:
            item = json.loads(event.read_text())
            path, repo = Path(item['path']), Path(item['repo'])
            if not path.exists() or not under(path, canonical('/private/tmp')):
                continue
            if worktree_metadata(repo, path).get('HEAD') != item['head']:
                continue
            if git(path, 'status', '--porcelain=v1', '--untracked-files=all'):
                continue
            run(['git', '-C', repo, 'merge-base', '--is-ancestor', item['head'], item['base']])
            marker = STATE / 'completed' / event.name
            if marker.exists() and json.loads(marker.read_text()).get('head') == item['head']:
                continue  # Repeated builds must not restart the cooling period.
            item['completed_at'] = time.time()
            item['source'] = 'successful-workflow-auto-registration'
            atomic_json(marker, item)
        except (OSError, ValueError, KeyError, RuntimeError, subprocess.SubprocessError):
            continue  # Pending evidence is retained for the next workflow end.


def worktree_check(item, usage, cutoff):
    path, repo = Path(item['path']), Path(item['repo'])
    assert_no_active_chats(repo)
    if canonical(path) != path or not under(path, canonical('/private/tmp')) or path.parent == path:
        raise RuntimeError('仅允许真实位于 /private/tmp 内的临时 worktree')
    meta = worktree_metadata(repo, path)
    if meta.get('HEAD') != item['head']:
        raise RuntimeError('完成标记之后 HEAD 已变化')
    if canonical(git(repo, 'rev-parse', '--show-toplevel').decode().strip()) == path:
        raise RuntimeError('不能删除仓库的主工作目录')
    if time.time() - item['completed_at'] < 24 * 3600:
        raise RuntimeError('完成标记不足 24 小时')
    assert_idle(path, usage)
    if git(path, 'status', '--porcelain=v1', '--untracked-files=all'):
        raise RuntimeError('存在未提交或未跟踪文件')
    # Require actual ancestry. Patch-equivalent cherry-picks are left for manual review.
    run(['git', '-C', repo, 'merge-base', '--is-ancestor', item['head'], item['base']])
    common = canonical(path / git(path, 'rev-parse', '--git-common-dir').decode().strip())
    gd = canonical(git(path, 'rev-parse', '--absolute-git-dir').decode().strip())
    for folder in {gd, common}:
        if list(folder.glob('*.lock')):
            raise RuntimeError('Git 锁存在')
    for flag in ['MERGE_HEAD', 'CHERRY_PICK_HEAD', 'REVERT_HEAD', 'rebase-apply', 'rebase-merge', 'BISECT_LOG']:
        if (gd / flag).exists():
            raise RuntimeError('Git 操作未结束')
    size = tree_info(path, cutoff)
    ignored = [os.fsdecode(x).rstrip('/') for x in git(path, 'ls-files', '--others', '--ignored', '--exclude-standard', '--directory', '-z').split(b'\0') if x]
    allowed = {'node_modules', 'apps/web/node_modules', 'apps/desktop/node_modules', 'apps/web/dist',
               'apps/web/.env.local', 'apps/web/.dev.vars', 'apps/web/.wrangler', 'supabase/.temp',
               'ios/CabinetKit/.swiftpm'}
    normalized = []
    def inspect_ignored(rel):
        if '..' in Path(rel).parts or Path(rel).is_absolute():
            raise RuntimeError('忽略路径异常')
        if rel in allowed:
            normalized.append(rel)
        elif any(a.startswith(rel + '/') for a in allowed) and not (path / rel).is_symlink():
            for child in (path / rel).iterdir():
                inspect_ignored(str(child.relative_to(path)))
        else:
            raise RuntimeError('包含未获自动清理许可的忽略文件')
    for rel in ignored:
        inspect_ignored(rel)
    ignored = normalized
    return size, ignored


def incoming_links(target, roots, limit=600000):
    """Scan configured workspaces, including dependency links. Stop safely if too large."""
    seen = 0
    for root in roots:
        root = canonical(root)
        if not root.is_dir():
            continue
        def fail(e):
            raise RuntimeError('依赖引用扫描不完整') from e
        for dp, ds, fs in os.walk(root, followlinks=False, onerror=fail):
            directory = Path(dp)
            if under(directory, target):
                ds[:] = []
                continue
            for name in ds + fs:
                seen += 1
                if seen > limit:
                    raise RuntimeError('依赖引用扫描达到上限，保留目录')
                p = directory / name
                if p.is_symlink() and under(canonical(p), target):
                    raise RuntimeError('其它目录有软链引用此工作目录')
            ds[:] = [n for n in ds if n != '.git' and not (directory / n).is_symlink()]


def backup_local(item, ignored, dest):
    path = Path(item['path'])
    manifest = {}
    dest.mkdir(parents=True, mode=0o700)
    for rel in ignored:
        if 'node_modules' in Path(rel).parts or rel == 'apps/web/dist':
            continue
        source, target = path / rel, dest / rel
        before = snapshot(source)
        for entry, value in before.items():
            if value[0] == 'link':
                link = source if entry == '.' else source / entry
                if not os.path.isabs(value[1]) or under(canonical(link), path):
                    raise RuntimeError('本地状态有相对软链或指向待删目录，保留原目录')
        target.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
        if source.is_symlink():
            # Keep external link exactly. Internal self-links need manual review.
            if under(canonical(source), path):
                raise RuntimeError('本地配置引用将删除的目录')
            target.symlink_to(os.readlink(source))
        elif source.is_dir():
            shutil.copytree(source, target, symlinks=True)
        else:
            shutil.copy2(source, target)
        if snapshot(target) != before or snapshot(source) != before:
            raise RuntimeError('本地状态备份校验失败')
        manifest[rel] = before
    atomic_json(dest / 'manifest.json', manifest)


def caches():
    # Deliberately exclude UV environments, Gradle, Docker, models and browser profiles.
    specs = [(HOME / '.npm/_npx', r'\b(?:node|npm|npx)\b'),
             (HOME / 'Library/Caches/Homebrew/downloads', r'\b(?:brew|Homebrew)\b')]
    for root, busy in specs:
        if root.is_symlink() or not root.is_dir() or canonical(root) != root:
            continue
        for p in root.iterdir():
            if not p.is_symlink() and p.is_dir() and root.name == '_npx':
                yield p, busy
            elif not p.is_symlink() and p.is_file() and root.name == 'downloads' and not p.name.endswith(('.incomplete', '.lock')):
                yield p, busy

    # Content-addressed download caches only; never Python/UV environments.
    for root, busy, depth in [
        (HOME / '.npm/_cacache/content-v2/sha512', r'\b(?:npm|npx|npm-cli|npx-cli)\b', 2),
        (HOME / 'Library/Caches/pip/http-v2', r'\b(?:pip|pip3|uv)\b', 2),
    ]:
        if root.is_symlink() or not root.is_dir() or canonical(root) != root:
            continue
        for dp, ds, fs in os.walk(root, followlinks=False):
            ds[:] = [n for n in ds if not (Path(dp) / n).is_symlink()]
            if len(Path(dp).relative_to(root).parts) == depth:
                yield Path(dp), busy
                ds[:] = []


def mark_done(args):
    repo, path = canonical(args.repo), canonical(args.done)
    meta = worktree_metadata(repo, path)
    if not under(path, canonical('/private/tmp')):
        raise RuntimeError('只登记 /private/tmp 内的临时 worktree')
    if git(path, 'status', '--porcelain=v1', '--untracked-files=all'):
        raise RuntimeError('有未提交内容，拒绝登记完成')
    run(['git', '-C', repo, 'merge-base', '--is-ancestor', meta['HEAD'], args.base])
    assert_idle(path, probe_usage())
    key = hashlib.sha256(str(path).encode()).hexdigest()[:24]
    item = {'path': str(path), 'repo': str(repo), 'head': meta['HEAD'], 'base': args.base,
            'completed_at': time.time(), 'source': 'explicit-completion-command'}
    atomic_json(STATE / 'completed' / (key + '.json'), item)
    print(f'已登记任务结束：{path}\n至少等待 24 小时，并满足目录闲置 72 小时后才会回收。')


def clean(args):
    promote_events()
    usage = probe_usage()
    report = {'started_at': time.time(), 'apply': args.apply,
              'free_before': shutil.disk_usage(HOME).free, 'items': []}
    stamp = time.strftime('%Y%m%d-%H%M%S') + f'-{os.getpid()}-{time.monotonic_ns()}'
    log = LOGS / f'disk-cleanup-{stamp}.json'
    LOGS.mkdir(parents=True, exist_ok=True, mode=0o700)
    with log.with_suffix('.jsonl').open('x', encoding='utf-8') as f:
        os.chmod(f.name, 0o600)
        f.write(json.dumps({'started_at': report['started_at'], 'apply': args.apply}) + '\n')
        f.flush()
        os.fsync(f.fileno())
    def record(path, state, reason='', size=0):
        report['items'].append({'path': str(path), 'state': state, 'reason': reason, 'allocated_bytes': size})
        event_log = log.with_suffix('.jsonl')
        with event_log.open('a', encoding='utf-8') as f:
            os.chmod(event_log, 0o600)
            f.write(json.dumps(report['items'][-1], ensure_ascii=False) + '\n')
            f.flush()
        if state != 'SKIP' or sum(x['state'] == 'SKIP' for x in report['items']) <= 8:
            print(f'{state:8s} {size / 1024**3:6.2f} GiB  {path}' + (f' · {reason}' if reason else ''), flush=True)
    cutoff_cache = time.time() - 7 * 86400
    for path, busy in caches():
        try:
            if re.search(busy, usage[1]):
                raise RuntimeError('相关工具正在运行')
            assert_idle(canonical(path), usage)
            if path.is_dir():
                size = tree_info(path, cutoff_cache)
            else:
                s = path.lstat()
                if max(s.st_mtime, s.st_ctime) > cutoff_cache:
                    raise RuntimeError('缓存不足 7 天')
                size = s.st_blocks * 512
            if args.apply:
                record(path, 'INTENT', '即将复核并清理缓存', size)
                fresh = probe_usage()
                if re.search(busy, fresh[1]):
                    raise RuntimeError('相关工具开始运行')
                assert_idle(canonical(path), fresh)
                if path.is_dir():
                    tree_info(path, cutoff_cache)
                    shutil.rmtree(path)
                else:
                    s = path.lstat()
                    if not stat.S_ISREG(s.st_mode) or max(s.st_mtime, s.st_ctime) > cutoff_cache:
                        raise RuntimeError('缓存状态变化')
                    path.unlink()
            record(path, 'REMOVED' if args.apply else 'READY', size=size)
        except (OSError, RuntimeError, subprocess.SubprocessError) as e:
            record(path, 'SKIP', str(e))
    for marker in sorted((STATE / 'completed').glob('*.json')):
        path = marker
        try:
            item = json.loads(marker.read_text())
            path = Path(item['path'])
            if not path.exists():
                record(path, 'GONE', '原目录已不存在')
                continue
            size, ignored = worktree_check(item, usage, time.time() - 72 * 3600)
            roots = [HOME / 'Desktop/APP', Path('/private/tmp'), HOME / '.codex/worktrees']
            incoming_links(path, roots)
            if args.apply:
                # Preserve every original commit, including detached HEADs.
                ref = 'refs/archive/josh-clean/' + stamp + '/' + marker.stem
                git(item['repo'], 'update-ref', ref, item['head'])
                backup_local(item, ignored, STATE / 'backups' / stamp / path.name)
                worktree_check(item, probe_usage(), time.time() - 72 * 3600)
                incoming_links(path, roots)
                record(path, 'INTENT', '备份和复核通过，即将移除工作目录', size)
                git(item['repo'], 'worktree', 'remove', str(path))  # Never --force.
                if path.exists():
                    raise RuntimeError('移除未完成')
            record(path, 'REMOVED' if args.apply else 'READY', size=size)
        except (OSError, ValueError, KeyError, RuntimeError, subprocess.SubprocessError) as e:
            record(path, 'SKIP', str(e))
    report['free_after'] = shutil.disk_usage(HOME).free
    report['finished_at'] = time.time()
    atomic_json(log, report)
    reclaimed = sum(x['allocated_bytes'] for x in report['items'] if x['state'] == 'REMOVED')
    skipped = sum(x['state'] == 'SKIP' for x in report['items'])
    print(f'\n跳过 {skipped} 项，完整原因见日志。')
    print(f'\n{"清理完成" if args.apply else "仅预览，没有删除"}；本次移除目录/文件占用合计 {reclaimed / 1024**3:.2f} GiB')
    print(f'当前可用 {report["free_after"] / 1024**3:.2f} GiB（并发写入/APFS 会影响净变化）\n日志：{log}')


def main(argv=None):
    parser = argparse.ArgumentParser(description='JoshLabs 离线安全磁盘清理：默认预览；--apply 执行。无 AI，无网络，无后台常驻。')
    parser.add_argument('--apply', action='store_true', help='清理符合规则的旧缓存和已登记结束的 worktree')
    parser.add_argument('--done', metavar='WORKTREE', help='明确登记此任务已结束；绑定当前 HEAD，之后仍须通过合并、闲置和占用检查')
    parser.add_argument('--repo', type=Path, default=DEFAULT_REPO, help='--done 所属仓库')
    parser.add_argument('--base', default='main', help='已合并目标（默认 main，要求实际祖先关系）')
    args = parser.parse_args(argv)
    if args.done and args.apply:
        parser.error('--done 和 --apply 不能同时使用')
    STATE.mkdir(parents=True, exist_ok=True, mode=0o700)
    with (STATE / 'cleanup.lock').open('a') as lock:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            raise RuntimeError('另一个清理进程正在执行，本次退出')
        try:
            os.nice(15)
        except OSError:
            pass
        if args.done:
            mark_done(args)
        else:
            clean(args)


if __name__ == '__main__':
    try:
        main()
    except (OSError, ValueError, RuntimeError, subprocess.SubprocessError) as e:
        print(f'已停止，保留数据：{e}', file=sys.stderr)
        sys.exit(1)
