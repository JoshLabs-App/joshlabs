#!/bin/bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
export PYTHONUNBUFFERED=1
exec /usr/bin/env python3 "$SCRIPT_DIR/josh_clean.py" "$@"
