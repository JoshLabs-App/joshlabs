#!/usr/bin/env python3
"""Run a build/release, preserve its exit status, dispatch one offline cleanup job."""
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time
import josh_clean as cleaner


def identity(cwd):
    try:
        path = cleaner.canonical(cleaner.git(cwd, 'rev-parse', '--show-toplevel').decode().strip())
        head = cleaner.git(path, 'rev-parse', 'HEAD').decode().strip()
        if cleaner.git(path, 'status', '--porcelain=v1', '--untracked-files=all'):
            return None
        # Use the main checkout as repository anchor, never a disposable worktree.
        raw = cleaner.git(path, 'worktree', 'list', '--porcelain', '-z')
        repo = cleaner.canonical(os.fsdecode(raw.split(b'\0', 1)[0]).removeprefix('worktree '))
        return {'path': str(path), 'repo': str(repo), 'head': head, 'base': 'main'}
    except (OSError, RuntimeError, subprocess.SubprocessError):
        return None


def dispatch(before, kind, status):
    cleaner.STATE.mkdir(parents=True, exist_ok=True, mode=0o700)
    cleaner.LOGS.mkdir(parents=True, exist_ok=True, mode=0o700)
    if status == 0 and before and identity(Path(before['path'])) == before:
        key = hashlib.sha256(before['path'].encode()).hexdigest()[:24]
        cleaner.atomic_json(cleaner.STATE / 'events' / (key + '.json'),
                            {**before, 'kind': kind, 'succeeded_at': time.time()})
    launch_cleanup()


def launch_cleanup():
    log = cleaner.LOGS / f'workflow-cleanup-{time.time_ns()}-{os.getpid()}.log'
    with log.open('x') as output:
        os.chmod(log, 0o600)
        subprocess.Popen([sys.executable, str(Path(cleaner.__file__).resolve()), '--apply'],
                         cwd=Path.home(), stdin=subprocess.DEVNULL, stdout=output,
                         stderr=subprocess.STDOUT, start_new_session=True, close_fds=True)


def main():
    if len(sys.argv) < 4 or sys.argv[1] not in ('build', 'publish') or sys.argv[2] != '--':
        print('Usage: josh-clean-run build|publish -- COMMAND [ARGS...]', file=sys.stderr)
        return 2
    before = identity(Path.cwd())
    child = None
    interrupted = None
    def forward(signum, frame):
        nonlocal interrupted
        interrupted = signum
        if child is not None:
            try:
                child.send_signal(signum)
            except ProcessLookupError:
                pass
    try:
        # Signal handlers allow finally/dispatch on normal interruption as well as failure.
        for sig in (signal.SIGINT, signal.SIGTERM, signal.SIGHUP):
            signal.signal(sig, forward)
        child = subprocess.Popen(sys.argv[3:])
        if interrupted is not None:
            forward(interrupted, None)
        code = child.wait()
        status = 128 + interrupted if interrupted is not None else (code if code >= 0 else 128 - code)
    except OSError as e:
        print(f'workflow: {e}', file=sys.stderr)
        status = 127
    try:
        dispatch(before, sys.argv[1], status)
    except Exception as e:
        print(f'清理钩子跳过（保留构建退出状态）: {e}', file=sys.stderr)
    return status


if __name__ == '__main__':
    sys.exit(main())
